﻿Imports System.Security.Cryptography
Imports System.Text
Imports System.IO
Public Class Form1
    Private Function GetBytes(ByVal text As String, ByVal length As Integer) As Byte()
        Dim bytes() As Byte = Encoding.UTF8.GetBytes(text)
        If bytes.Length > length Then
            Dim cut(length - 1) As Byte
            Array.Copy(bytes, cut, length)
            Return cut
        ElseIf bytes.Length < length Then
            ReDim Preserve bytes(length - 1)
            Return bytes
        Else
            Return bytes
        End If
    End Function

    Private aesKey As Byte() = GetBytes("ArixSecureKey1234", 16) ' 16 bytes
    Private aesIV As Byte() = GetBytes("ArixSecureIV1234", 16)   ' 16 bytes

    Public Function HashSHA256(ByVal input As String) As String
        Dim sha As New SHA256Managed()
        Dim bytes As Byte() = Encoding.UTF8.GetBytes(input)
        Dim hash As Byte() = sha.ComputeHash(bytes)
        Return BitConverter.ToString(hash).Replace("-", "")
    End Function

    Public Function EncryptAES(ByVal plainText As String) As String
        Dim aes As New RijndaelManaged()
        aes.KeySize = 128
        aes.BlockSize = 128
        aes.Key = aesKey
        aes.IV = aesIV
        aes.Mode = CipherMode.CBC
        aes.Padding = PaddingMode.PKCS7
        Dim encryptor As ICryptoTransform = aes.CreateEncryptor()
        Using ms As New MemoryStream()
            Using cs As New CryptoStream(ms, encryptor, CryptoStreamMode.Write)
                Dim bytes As Byte() = Encoding.UTF8.GetBytes(plainText)
                cs.Write(bytes, 0, bytes.Length)
                cs.Close()
            End Using
            Return Convert.ToBase64String(ms.ToArray())
        End Using
    End Function

    Public Function DecryptAES(ByVal cipherText As String) As String
        Dim aes As New RijndaelManaged()
        aes.KeySize = 128
        aes.BlockSize = 128
        aes.Key = aesKey
        aes.IV = aesIV
        aes.Mode = CipherMode.CBC
        aes.Padding = PaddingMode.PKCS7
        Dim decryptor As ICryptoTransform = aes.CreateDecryptor()
        Using ms As New MemoryStream(Convert.FromBase64String(cipherText))
            Using cs As New CryptoStream(ms, decryptor, CryptoStreamMode.Read)
                Using reader As New StreamReader(cs)
                    Return reader.ReadToEnd()
                End Using
            End Using
        End Using
    End Function
    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Clipboard.SetText(TextBox2.Text)
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim input As String = TextBox1.Text.Trim
        If input = "" Then
            MessageBox.Show("Masukkan teks terlebih dahulu!")
            Exit Sub
        End If
        Dim hashed As String = HashSHA256(input)
        Dim serial As String = EncryptAES(hashed)
        TextBox2.Text = serial
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Dim input As String = TextBox1.Text.Trim
        Dim serial As String = TextBox2.Text.Trim
        If input = "" Or serial = "" Then
            MessageBox.Show("Isi kedua kolom terlebih dahulu!")
            Exit Sub
        End If
        Try
            Dim hashedInput As String = HashSHA256(input)
            Dim decryptedSerial As String = DecryptAES(serial)
            If hashedInput = decryptedSerial Then
                MessageBox.Show("Serial Valid!")
            Else
                MessageBox.Show("Serial Tidak Valid!")
            End If
        Catch ex As Exception
            MessageBox.Show("Serial Tidak Valid atau Rusak!" & vbCrLf & ex.Message)
        End Try
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim sfd As New SaveFileDialog()
        sfd.Filter = "Key Files (*.ky)|*.ky"
        sfd.Title = "Save Key File"
        If sfd.ShowDialog() = DialogResult.OK Then
            Try
                System.IO.File.WriteAllText(sfd.FileName, TextBox2.Text)
                MessageBox.Show("File berhasil disimpan!", "Sukses", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Catch ex As Exception
                MessageBox.Show("Gagal menyimpan: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub
End Class
