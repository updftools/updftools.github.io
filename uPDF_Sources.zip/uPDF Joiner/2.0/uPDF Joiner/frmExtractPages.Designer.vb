﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmExtractPages
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.extract_filename = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.extract_dir = New System.Windows.Forms.Label()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.extract_date = New System.Windows.Forms.Label()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.extract_size = New System.Windows.Forms.Label()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.extract_pages = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.extract_selectpages = New System.Windows.Forms.Label()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.btn_extract = New System.Windows.Forms.Button()
        Me.btn_cancel = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.txt_statusextract = New System.Windows.Forms.TextBox()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'extract_filename
        '
        Me.extract_filename.AutoSize = True
        Me.extract_filename.Location = New System.Drawing.Point(12, 9)
        Me.extract_filename.Name = "extract_filename"
        Me.extract_filename.Size = New System.Drawing.Size(49, 13)
        Me.extract_filename.TabIndex = 0
        Me.extract_filename.Text = "Filename"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(12, 25)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ReadOnly = True
        Me.TextBox1.Size = New System.Drawing.Size(294, 20)
        Me.TextBox1.TabIndex = 1
        Me.TextBox1.TabStop = False
        Me.TextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(12, 65)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.ReadOnly = True
        Me.TextBox2.Size = New System.Drawing.Size(294, 20)
        Me.TextBox2.TabIndex = 3
        Me.TextBox2.TabStop = False
        Me.TextBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'extract_dir
        '
        Me.extract_dir.AutoSize = True
        Me.extract_dir.Location = New System.Drawing.Point(12, 49)
        Me.extract_dir.Name = "extract_dir"
        Me.extract_dir.Size = New System.Drawing.Size(49, 13)
        Me.extract_dir.TabIndex = 2
        Me.extract_dir.Text = "Directory"
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(12, 105)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.ReadOnly = True
        Me.TextBox3.Size = New System.Drawing.Size(294, 20)
        Me.TextBox3.TabIndex = 5
        Me.TextBox3.TabStop = False
        Me.TextBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'extract_date
        '
        Me.extract_date.AutoSize = True
        Me.extract_date.Location = New System.Drawing.Point(12, 89)
        Me.extract_date.Name = "extract_date"
        Me.extract_date.Size = New System.Drawing.Size(70, 13)
        Me.extract_date.TabIndex = 4
        Me.extract_date.Text = "Date Created"
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(12, 145)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.ReadOnly = True
        Me.TextBox4.Size = New System.Drawing.Size(294, 20)
        Me.TextBox4.TabIndex = 7
        Me.TextBox4.TabStop = False
        Me.TextBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'extract_size
        '
        Me.extract_size.AutoSize = True
        Me.extract_size.Location = New System.Drawing.Point(12, 129)
        Me.extract_size.Name = "extract_size"
        Me.extract_size.Size = New System.Drawing.Size(27, 13)
        Me.extract_size.TabIndex = 6
        Me.extract_size.Text = "Size"
        '
        'TextBox5
        '
        Me.TextBox5.Location = New System.Drawing.Point(12, 185)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.ReadOnly = True
        Me.TextBox5.Size = New System.Drawing.Size(63, 20)
        Me.TextBox5.TabIndex = 9
        Me.TextBox5.TabStop = False
        Me.TextBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'extract_pages
        '
        Me.extract_pages.AutoSize = True
        Me.extract_pages.Location = New System.Drawing.Point(12, 169)
        Me.extract_pages.Name = "extract_pages"
        Me.extract_pages.Size = New System.Drawing.Size(64, 13)
        Me.extract_pages.TabIndex = 8
        Me.extract_pages.Text = "Total Pages"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Panel1.Location = New System.Drawing.Point(12, 212)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(294, 1)
        Me.Panel1.TabIndex = 10
        '
        'extract_selectpages
        '
        Me.extract_selectpages.AutoSize = True
        Me.extract_selectpages.Location = New System.Drawing.Point(12, 216)
        Me.extract_selectpages.Name = "extract_selectpages"
        Me.extract_selectpages.Size = New System.Drawing.Size(113, 13)
        Me.extract_selectpages.TabIndex = 11
        Me.extract_selectpages.Text = "Select Page to Extract"
        '
        'TextBox6
        '
        Me.TextBox6.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox6.Location = New System.Drawing.Point(12, 232)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(294, 23)
        Me.TextBox6.TabIndex = 12
        Me.TextBox6.TabStop = False
        Me.TextBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btn_extract
        '
        Me.btn_extract.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_extract.Location = New System.Drawing.Point(209, 8)
        Me.btn_extract.Name = "btn_extract"
        Me.btn_extract.Size = New System.Drawing.Size(97, 39)
        Me.btn_extract.TabIndex = 13
        Me.btn_extract.TabStop = False
        Me.btn_extract.Text = "Extract [ENTER]"
        Me.btn_extract.UseVisualStyleBackColor = True
        '
        'btn_cancel
        '
        Me.btn_cancel.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_cancel.Location = New System.Drawing.Point(130, 8)
        Me.btn_cancel.Name = "btn_cancel"
        Me.btn_cancel.Size = New System.Drawing.Size(73, 39)
        Me.btn_cancel.TabIndex = 14
        Me.btn_cancel.TabStop = False
        Me.btn_cancel.Text = "Cancel"
        Me.btn_cancel.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.Control
        Me.Panel2.Controls.Add(Me.btn_extract)
        Me.Panel2.Controls.Add(Me.btn_cancel)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel2.Location = New System.Drawing.Point(0, 343)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(318, 56)
        Me.Panel2.TabIndex = 16
        '
        'txt_statusextract
        '
        Me.txt_statusextract.BackColor = System.Drawing.SystemColors.Info
        Me.txt_statusextract.Location = New System.Drawing.Point(12, 261)
        Me.txt_statusextract.Multiline = True
        Me.txt_statusextract.Name = "txt_statusextract"
        Me.txt_statusextract.ReadOnly = True
        Me.txt_statusextract.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txt_statusextract.Size = New System.Drawing.Size(294, 65)
        Me.txt_statusextract.TabIndex = 17
        Me.txt_statusextract.TabStop = False
        Me.txt_statusextract.Text = "Extract selected pages from a PDF file by: if only one page, just write the page " & _
            "number to be extracted, for example [2]; if more than one page, write [3,4,8,etc" & _
            ".], using a comma (,) as a separator."
        '
        'frmExtractPages
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ClientSize = New System.Drawing.Size(318, 399)
        Me.ControlBox = False
        Me.Controls.Add(Me.txt_statusextract)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.TextBox6)
        Me.Controls.Add(Me.extract_selectpages)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.TextBox5)
        Me.Controls.Add(Me.extract_pages)
        Me.Controls.Add(Me.TextBox4)
        Me.Controls.Add(Me.extract_size)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.extract_date)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.extract_dir)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.extract_filename)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmExtractPages"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Extract Pages"
        Me.TopMost = True
        Me.Panel2.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents extract_filename As System.Windows.Forms.Label
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents extract_dir As System.Windows.Forms.Label
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents extract_date As System.Windows.Forms.Label
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents extract_size As System.Windows.Forms.Label
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
    Friend WithEvents extract_pages As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents extract_selectpages As System.Windows.Forms.Label
    Friend WithEvents TextBox6 As System.Windows.Forms.TextBox
    Friend WithEvents btn_extract As System.Windows.Forms.Button
    Friend WithEvents btn_cancel As System.Windows.Forms.Button
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents txt_statusextract As System.Windows.Forms.TextBox
End Class
