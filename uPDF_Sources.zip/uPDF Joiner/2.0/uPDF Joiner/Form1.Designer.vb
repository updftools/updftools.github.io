﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Pagess = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Filename = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.filesize = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.filepath = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.btn_Extract = New System.Windows.Forms.ToolStripButton()
        Me.btn_Split = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.btn_remove = New System.Windows.Forms.ToolStripButton()
        Me.btn_clear = New System.Windows.Forms.ToolStripButton()
        Me.ToolStrip2 = New System.Windows.Forms.ToolStrip()
        Me.btn_addpdf = New System.Windows.Forms.ToolStripButton()
        Me.btn_save = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.btn_help = New System.Windows.Forms.ToolStripSplitButton()
        Me.mnu_content = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnu_registration = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContributeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.mnu_about = New System.Windows.Forms.ToolStripMenuItem()
        Me.g_options = New System.Windows.Forms.GroupBox()
        Me.chk_protect = New System.Windows.Forms.CheckBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.chk_watermark = New System.Windows.Forms.CheckBox()
        Me.g_compression = New System.Windows.Forms.GroupBox()
        Me.rc_best = New System.Windows.Forms.RadioButton()
        Me.rc_default = New System.Windows.Forms.RadioButton()
        Me.rc_no = New System.Windows.Forms.RadioButton()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.txt_status = New System.Windows.Forms.Label()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.MergeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddFilesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MergeToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExtractToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SplitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RemoveToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RemoveToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClearToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.txt_settings = New System.Windows.Forms.Label()
        Me.lbtrial = New System.Windows.Forms.Label()
        Me.lbHWID = New System.Windows.Forms.Label()
        Me.txtKey = New System.Windows.Forms.TextBox()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.txt_status2 = New System.Windows.Forms.Label()
        Me.txt_status3 = New System.Windows.Forms.TextBox()
        Me.usa = New System.Windows.Forms.Button()
        Me.indo = New System.Windows.Forms.Button()
        Me.th = New System.Windows.Forms.Button()
        Me.text_lang = New System.Windows.Forms.Label()
        Me.jp = New System.Windows.Forms.Button()
        Me.ph = New System.Windows.Forms.Button()
        Me.viet = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.timor = New System.Windows.Forms.Button()
        Me.lblang = New System.Windows.Forms.Label()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ToolStrip1.SuspendLayout()
        Me.ToolStrip2.SuspendLayout()
        Me.g_options.SuspendLayout()
        Me.g_compression.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        Me.Panel4.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowDrop = True
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.DataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight
        Me.DataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.DataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None
        Me.DataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Pagess, Me.Filename, Me.filesize, Me.filepath})
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.Desktop
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridView1.DefaultCellStyle = DataGridViewCellStyle2
        Me.DataGridView1.Location = New System.Drawing.Point(9, 78)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.RowHeadersVisible = False
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView1.Size = New System.Drawing.Size(472, 277)
        Me.DataGridView1.TabIndex = 1
        '
        'Pagess
        '
        Me.Pagess.HeaderText = "Total Pages"
        Me.Pagess.Name = "Pagess"
        Me.Pagess.ReadOnly = True
        Me.Pagess.Width = 150
        '
        'Filename
        '
        Me.Filename.HeaderText = "File Name"
        Me.Filename.Name = "Filename"
        Me.Filename.ReadOnly = True
        Me.Filename.Width = 200
        '
        'filesize
        '
        Me.filesize.HeaderText = "Size"
        Me.filesize.Name = "filesize"
        Me.filesize.ReadOnly = True
        '
        'filepath
        '
        Me.filepath.HeaderText = "Directory"
        Me.filepath.Name = "filepath"
        Me.filepath.ReadOnly = True
        Me.filepath.Width = 210
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Dock = System.Windows.Forms.DockStyle.None
        Me.ToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.btn_Extract, Me.btn_Split, Me.ToolStripSeparator1, Me.btn_remove, Me.btn_clear})
        Me.ToolStrip1.Location = New System.Drawing.Point(9, 359)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.System
        Me.ToolStrip1.Size = New System.Drawing.Size(347, 25)
        Me.ToolStrip1.TabIndex = 9
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'btn_Extract
        '
        Me.btn_Extract.Image = Global.uPDF_Joiner.My.Resources.Resources.extract
        Me.btn_Extract.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btn_Extract.Name = "btn_Extract"
        Me.btn_Extract.Size = New System.Drawing.Size(97, 22)
        Me.btn_Extract.Text = "Extract Pages"
        '
        'btn_Split
        '
        Me.btn_Split.Image = Global.uPDF_Joiner.My.Resources.Resources.split
        Me.btn_Split.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btn_Split.Name = "btn_Split"
        Me.btn_Split.Size = New System.Drawing.Size(100, 22)
        Me.btn_Split.Text = "Split PDF Files"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'btn_remove
        '
        Me.btn_remove.Image = Global.uPDF_Joiner.My.Resources.Resources._rem
        Me.btn_remove.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btn_remove.Name = "btn_remove"
        Me.btn_remove.Size = New System.Drawing.Size(70, 22)
        Me.btn_remove.Text = "Remove"
        '
        'btn_clear
        '
        Me.btn_clear.Image = Global.uPDF_Joiner.My.Resources.Resources.clr
        Me.btn_clear.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btn_clear.Name = "btn_clear"
        Me.btn_clear.Size = New System.Drawing.Size(71, 22)
        Me.btn_clear.Text = "Clear All"
        '
        'ToolStrip2
        '
        Me.ToolStrip2.Dock = System.Windows.Forms.DockStyle.None
        Me.ToolStrip2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStrip2.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.ToolStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.btn_addpdf, Me.btn_save, Me.ToolStripSeparator2, Me.btn_help})
        Me.ToolStrip2.Location = New System.Drawing.Point(9, 5)
        Me.ToolStrip2.Name = "ToolStrip2"
        Me.ToolStrip2.RenderMode = System.Windows.Forms.ToolStripRenderMode.System
        Me.ToolStrip2.Size = New System.Drawing.Size(286, 31)
        Me.ToolStrip2.TabIndex = 10
        Me.ToolStrip2.Text = "ToolStrip2"
        '
        'btn_addpdf
        '
        Me.btn_addpdf.Image = Global.uPDF_Joiner.My.Resources.Resources.bfolder
        Me.btn_addpdf.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.btn_addpdf.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btn_addpdf.Name = "btn_addpdf"
        Me.btn_addpdf.Size = New System.Drawing.Size(102, 28)
        Me.btn_addpdf.Text = "Add PDF Files"
        '
        'btn_save
        '
        Me.btn_save.Image = Global.uPDF_Joiner.My.Resources.Resources.isave
        Me.btn_save.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.btn_save.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btn_save.Name = "btn_save"
        Me.btn_save.Size = New System.Drawing.Size(114, 28)
        Me.btn_save.Text = "Save and Merge"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 31)
        '
        'btn_help
        '
        Me.btn_help.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnu_content, Me.mnu_registration, Me.ContributeToolStripMenuItem, Me.ToolStripSeparator3, Me.mnu_about})
        Me.btn_help.Image = Global.uPDF_Joiner.My.Resources.Resources.ihelp
        Me.btn_help.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btn_help.Name = "btn_help"
        Me.btn_help.Size = New System.Drawing.Size(61, 28)
        Me.btn_help.Text = "Help"
        '
        'mnu_content
        '
        Me.mnu_content.Image = Global.uPDF_Joiner.My.Resources.Resources.h
        Me.mnu_content.Name = "mnu_content"
        Me.mnu_content.ShortcutKeys = System.Windows.Forms.Keys.F1
        Me.mnu_content.Size = New System.Drawing.Size(179, 22)
        Me.mnu_content.Text = "Content"
        '
        'mnu_registration
        '
        Me.mnu_registration.Image = Global.uPDF_Joiner.My.Resources.Resources.keys16
        Me.mnu_registration.Name = "mnu_registration"
        Me.mnu_registration.Size = New System.Drawing.Size(179, 22)
        Me.mnu_registration.Text = "Enter Registration Key"
        '
        'ContributeToolStripMenuItem
        '
        Me.ContributeToolStripMenuItem.Image = Global.uPDF_Joiner.My.Resources.Resources.contribute
        Me.ContributeToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ContributeToolStripMenuItem.Name = "ContributeToolStripMenuItem"
        Me.ContributeToolStripMenuItem.Size = New System.Drawing.Size(179, 22)
        Me.ContributeToolStripMenuItem.Text = "Contribute"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(176, 6)
        '
        'mnu_about
        '
        Me.mnu_about.Image = Global.uPDF_Joiner.My.Resources.Resources.iinfo
        Me.mnu_about.Name = "mnu_about"
        Me.mnu_about.Size = New System.Drawing.Size(179, 22)
        Me.mnu_about.Text = "About"
        '
        'g_options
        '
        Me.g_options.Controls.Add(Me.chk_protect)
        Me.g_options.Controls.Add(Me.TextBox1)
        Me.g_options.Controls.Add(Me.chk_watermark)
        Me.g_options.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.g_options.Location = New System.Drawing.Point(9, 419)
        Me.g_options.Name = "g_options"
        Me.g_options.Size = New System.Drawing.Size(153, 107)
        Me.g_options.TabIndex = 11
        Me.g_options.TabStop = False
        Me.g_options.Text = "Options"
        '
        'chk_protect
        '
        Me.chk_protect.AutoSize = True
        Me.chk_protect.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_protect.Location = New System.Drawing.Point(6, 75)
        Me.chk_protect.Name = "chk_protect"
        Me.chk_protect.Size = New System.Drawing.Size(84, 17)
        Me.chk_protect.TabIndex = 2
        Me.chk_protect.Text = "Protect PDF"
        Me.chk_protect.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.Enabled = False
        Me.TextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.Location = New System.Drawing.Point(22, 46)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(123, 20)
        Me.TextBox1.TabIndex = 1
        Me.TextBox1.Text = "Watermark text here"
        Me.TextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'chk_watermark
        '
        Me.chk_watermark.AutoSize = True
        Me.chk_watermark.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_watermark.Location = New System.Drawing.Point(6, 21)
        Me.chk_watermark.Name = "chk_watermark"
        Me.chk_watermark.Size = New System.Drawing.Size(100, 17)
        Me.chk_watermark.TabIndex = 0
        Me.chk_watermark.Text = "Add Watermark"
        Me.chk_watermark.UseVisualStyleBackColor = True
        '
        'g_compression
        '
        Me.g_compression.Controls.Add(Me.rc_best)
        Me.g_compression.Controls.Add(Me.rc_default)
        Me.g_compression.Controls.Add(Me.rc_no)
        Me.g_compression.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.g_compression.Location = New System.Drawing.Point(168, 419)
        Me.g_compression.Name = "g_compression"
        Me.g_compression.Size = New System.Drawing.Size(151, 107)
        Me.g_compression.TabIndex = 12
        Me.g_compression.TabStop = False
        Me.g_compression.Text = "Compression"
        '
        'rc_best
        '
        Me.rc_best.AutoSize = True
        Me.rc_best.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rc_best.Location = New System.Drawing.Point(8, 71)
        Me.rc_best.Name = "rc_best"
        Me.rc_best.Size = New System.Drawing.Size(109, 17)
        Me.rc_best.TabIndex = 2
        Me.rc_best.Text = "Best Compression"
        Me.rc_best.UseVisualStyleBackColor = True
        '
        'rc_default
        '
        Me.rc_default.AutoSize = True
        Me.rc_default.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rc_default.Location = New System.Drawing.Point(8, 46)
        Me.rc_default.Name = "rc_default"
        Me.rc_default.Size = New System.Drawing.Size(122, 17)
        Me.rc_default.TabIndex = 1
        Me.rc_default.Text = "Default Compression"
        Me.rc_default.UseVisualStyleBackColor = True
        '
        'rc_no
        '
        Me.rc_no.AutoSize = True
        Me.rc_no.Checked = True
        Me.rc_no.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rc_no.Location = New System.Drawing.Point(8, 21)
        Me.rc_no.Name = "rc_no"
        Me.rc_no.Size = New System.Drawing.Size(102, 17)
        Me.rc_no.TabIndex = 0
        Me.rc_no.TabStop = True
        Me.rc_no.Text = "No Compression"
        Me.rc_no.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.PictureBox1)
        Me.Panel1.Controls.Add(Me.txt_status)
        Me.Panel1.Location = New System.Drawing.Point(9, 42)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(472, 33)
        Me.Panel1.TabIndex = 13
        '
        'PictureBox1
        '
        Me.PictureBox1.Dock = System.Windows.Forms.DockStyle.Right
        Me.PictureBox1.Location = New System.Drawing.Point(440, 0)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(32, 33)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'txt_status
        '
        Me.txt_status.Dock = System.Windows.Forms.DockStyle.Left
        Me.txt_status.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_status.Location = New System.Drawing.Point(0, 0)
        Me.txt_status.Name = "txt_status"
        Me.txt_status.Size = New System.Drawing.Size(434, 33)
        Me.txt_status.TabIndex = 1
        Me.txt_status.Text = "Drag and Drop PDF Files"
        Me.txt_status.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Dock = System.Windows.Forms.DockStyle.None
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MergeToolStripMenuItem, Me.RemoveToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(270, 13)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(146, 24)
        Me.MenuStrip1.TabIndex = 16
        Me.MenuStrip1.Text = "MenuStrip1"
        Me.MenuStrip1.Visible = False
        '
        'MergeToolStripMenuItem
        '
        Me.MergeToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AddFilesToolStripMenuItem, Me.MergeToolStripMenuItem1, Me.ExtractToolStripMenuItem, Me.SplitToolStripMenuItem})
        Me.MergeToolStripMenuItem.Name = "MergeToolStripMenuItem"
        Me.MergeToolStripMenuItem.Size = New System.Drawing.Size(76, 20)
        Me.MergeToolStripMenuItem.Text = "Command"
        '
        'AddFilesToolStripMenuItem
        '
        Me.AddFilesToolStripMenuItem.Name = "AddFilesToolStripMenuItem"
        Me.AddFilesToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.O), System.Windows.Forms.Keys)
        Me.AddFilesToolStripMenuItem.Size = New System.Drawing.Size(165, 22)
        Me.AddFilesToolStripMenuItem.Text = "Add Files"
        '
        'MergeToolStripMenuItem1
        '
        Me.MergeToolStripMenuItem1.Name = "MergeToolStripMenuItem1"
        Me.MergeToolStripMenuItem1.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.S), System.Windows.Forms.Keys)
        Me.MergeToolStripMenuItem1.Size = New System.Drawing.Size(165, 22)
        Me.MergeToolStripMenuItem1.Text = "Merge"
        '
        'ExtractToolStripMenuItem
        '
        Me.ExtractToolStripMenuItem.Name = "ExtractToolStripMenuItem"
        Me.ExtractToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.E), System.Windows.Forms.Keys)
        Me.ExtractToolStripMenuItem.Size = New System.Drawing.Size(165, 22)
        Me.ExtractToolStripMenuItem.Text = "Extract"
        '
        'SplitToolStripMenuItem
        '
        Me.SplitToolStripMenuItem.Name = "SplitToolStripMenuItem"
        Me.SplitToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.T), System.Windows.Forms.Keys)
        Me.SplitToolStripMenuItem.Size = New System.Drawing.Size(165, 22)
        Me.SplitToolStripMenuItem.Text = "Split"
        '
        'RemoveToolStripMenuItem
        '
        Me.RemoveToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RemoveToolStripMenuItem1, Me.ClearToolStripMenuItem})
        Me.RemoveToolStripMenuItem.Name = "RemoveToolStripMenuItem"
        Me.RemoveToolStripMenuItem.Size = New System.Drawing.Size(62, 20)
        Me.RemoveToolStripMenuItem.Text = "Remove"
        '
        'RemoveToolStripMenuItem1
        '
        Me.RemoveToolStripMenuItem1.Name = "RemoveToolStripMenuItem1"
        Me.RemoveToolStripMenuItem1.ShortcutKeys = System.Windows.Forms.Keys.Delete
        Me.RemoveToolStripMenuItem1.Size = New System.Drawing.Size(142, 22)
        Me.RemoveToolStripMenuItem1.Text = "Remove"
        '
        'ClearToolStripMenuItem
        '
        Me.ClearToolStripMenuItem.Name = "ClearToolStripMenuItem"
        Me.ClearToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.R), System.Windows.Forms.Keys)
        Me.ClearToolStripMenuItem.Size = New System.Drawing.Size(142, 22)
        Me.ClearToolStripMenuItem.Text = "Clear"
        '
        'txt_settings
        '
        Me.txt_settings.AutoSize = True
        Me.txt_settings.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_settings.Location = New System.Drawing.Point(6, 392)
        Me.txt_settings.Name = "txt_settings"
        Me.txt_settings.Size = New System.Drawing.Size(53, 13)
        Me.txt_settings.TabIndex = 29
        Me.txt_settings.Text = "Settings"
        '
        'lbtrial
        '
        Me.lbtrial.BackColor = System.Drawing.Color.MistyRose
        Me.lbtrial.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbtrial.Location = New System.Drawing.Point(12, 529)
        Me.lbtrial.Name = "lbtrial"
        Me.lbtrial.Size = New System.Drawing.Size(45, 52)
        Me.lbtrial.TabIndex = 44
        Me.lbtrial.Text = "Trial"
        Me.lbtrial.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lbHWID
        '
        Me.lbHWID.AutoSize = True
        Me.lbHWID.Location = New System.Drawing.Point(6, 639)
        Me.lbHWID.Name = "lbHWID"
        Me.lbHWID.Size = New System.Drawing.Size(29, 15)
        Me.lbHWID.TabIndex = 49
        Me.lbHWID.Text = "%%"
        '
        'txtKey
        '
        Me.txtKey.Enabled = False
        Me.txtKey.Location = New System.Drawing.Point(56, 639)
        Me.txtKey.Name = "txtKey"
        Me.txtKey.Size = New System.Drawing.Size(100, 21)
        Me.txtKey.TabIndex = 50
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.PictureBox2)
        Me.Panel4.Location = New System.Drawing.Point(11, 527)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(308, 54)
        Me.Panel4.TabIndex = 51
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = Global.uPDF_Joiner.My.Resources.Resources.iloading
        Me.PictureBox2.Location = New System.Drawing.Point(141, 16)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(18, 19)
        Me.PictureBox2.TabIndex = 17
        Me.PictureBox2.TabStop = False
        '
        'Button2
        '
        Me.Button2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button2.Image = Global.uPDF_Joiner.My.Resources.Resources.btndown
        Me.Button2.Location = New System.Drawing.Point(487, 207)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(21, 25)
        Me.Button2.TabIndex = 15
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button1.Image = Global.uPDF_Joiner.My.Resources.Resources.btnup
        Me.Button1.Location = New System.Drawing.Point(487, 176)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(21, 25)
        Me.Button1.TabIndex = 14
        Me.Button1.UseVisualStyleBackColor = True
        '
        'txt_status2
        '
        Me.txt_status2.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.txt_status2.Location = New System.Drawing.Point(13, 166)
        Me.txt_status2.Name = "txt_status2"
        Me.txt_status2.Size = New System.Drawing.Size(465, 106)
        Me.txt_status2.TabIndex = 52
        Me.txt_status2.Text = " Drag and drop PDF files here"
        Me.txt_status2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txt_status3
        '
        Me.txt_status3.BackColor = System.Drawing.SystemColors.Info
        Me.txt_status3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txt_status3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_status3.Location = New System.Drawing.Point(56, 529)
        Me.txt_status3.Multiline = True
        Me.txt_status3.Name = "txt_status3"
        Me.txt_status3.ReadOnly = True
        Me.txt_status3.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txt_status3.Size = New System.Drawing.Size(265, 52)
        Me.txt_status3.TabIndex = 55
        Me.txt_status3.TabStop = False
        Me.txt_status3.Text = "Only 3 PDF files can be added, switch to the PRO version for only $5 and you can " & _
            "add unlimited files."
        Me.txt_status3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'usa
        '
        Me.usa.Cursor = System.Windows.Forms.Cursors.Hand
        Me.usa.FlatAppearance.BorderSize = 0
        Me.usa.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red
        Me.usa.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.usa.Image = Global.uPDF_Joiner.My.Resources.Resources.usa
        Me.usa.Location = New System.Drawing.Point(3, 5)
        Me.usa.Name = "usa"
        Me.usa.Size = New System.Drawing.Size(48, 35)
        Me.usa.TabIndex = 56
        Me.usa.TabStop = False
        Me.usa.UseVisualStyleBackColor = True
        '
        'indo
        '
        Me.indo.BackColor = System.Drawing.SystemColors.Control
        Me.indo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.indo.Cursor = System.Windows.Forms.Cursors.Hand
        Me.indo.FlatAppearance.BorderSize = 0
        Me.indo.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Coral
        Me.indo.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.indo.Image = Global.uPDF_Joiner.My.Resources.Resources.indonesia
        Me.indo.Location = New System.Drawing.Point(55, 5)
        Me.indo.Name = "indo"
        Me.indo.Size = New System.Drawing.Size(48, 35)
        Me.indo.TabIndex = 57
        Me.indo.TabStop = False
        Me.indo.UseVisualStyleBackColor = False
        '
        'th
        '
        Me.th.Cursor = System.Windows.Forms.Cursors.Hand
        Me.th.FlatAppearance.BorderSize = 0
        Me.th.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red
        Me.th.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.th.Image = Global.uPDF_Joiner.My.Resources.Resources.thailand
        Me.th.Location = New System.Drawing.Point(55, 47)
        Me.th.Name = "th"
        Me.th.Size = New System.Drawing.Size(48, 35)
        Me.th.TabIndex = 58
        Me.th.TabStop = False
        Me.th.UseVisualStyleBackColor = True
        '
        'text_lang
        '
        Me.text_lang.AutoSize = True
        Me.text_lang.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.text_lang.Location = New System.Drawing.Point(322, 392)
        Me.text_lang.Name = "text_lang"
        Me.text_lang.Size = New System.Drawing.Size(63, 13)
        Me.text_lang.TabIndex = 59
        Me.text_lang.Text = "Language"
        '
        'jp
        '
        Me.jp.Cursor = System.Windows.Forms.Cursors.Hand
        Me.jp.FlatAppearance.BorderSize = 0
        Me.jp.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red
        Me.jp.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.jp.Image = Global.uPDF_Joiner.My.Resources.Resources.japan
        Me.jp.Location = New System.Drawing.Point(108, 5)
        Me.jp.Name = "jp"
        Me.jp.Size = New System.Drawing.Size(48, 35)
        Me.jp.TabIndex = 60
        Me.jp.TabStop = False
        Me.jp.UseVisualStyleBackColor = True
        '
        'ph
        '
        Me.ph.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ph.FlatAppearance.BorderSize = 0
        Me.ph.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red
        Me.ph.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.ph.Image = Global.uPDF_Joiner.My.Resources.Resources.philippines
        Me.ph.Location = New System.Drawing.Point(3, 47)
        Me.ph.Name = "ph"
        Me.ph.Size = New System.Drawing.Size(48, 35)
        Me.ph.TabIndex = 61
        Me.ph.TabStop = False
        Me.ph.UseVisualStyleBackColor = True
        '
        'viet
        '
        Me.viet.Cursor = System.Windows.Forms.Cursors.Hand
        Me.viet.FlatAppearance.BorderSize = 0
        Me.viet.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red
        Me.viet.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.viet.Image = Global.uPDF_Joiner.My.Resources.Resources.vietnam
        Me.viet.Location = New System.Drawing.Point(3, 88)
        Me.viet.Name = "viet"
        Me.viet.Size = New System.Drawing.Size(48, 35)
        Me.viet.TabIndex = 62
        Me.viet.TabStop = False
        Me.viet.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.AutoScroll = True
        Me.Panel2.BackColor = System.Drawing.SystemColors.Menu
        Me.Panel2.Controls.Add(Me.Label1)
        Me.Panel2.Controls.Add(Me.timor)
        Me.Panel2.Controls.Add(Me.usa)
        Me.Panel2.Controls.Add(Me.viet)
        Me.Panel2.Controls.Add(Me.indo)
        Me.Panel2.Controls.Add(Me.ph)
        Me.Panel2.Controls.Add(Me.th)
        Me.Panel2.Controls.Add(Me.jp)
        Me.Panel2.Location = New System.Drawing.Point(325, 419)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(179, 107)
        Me.Panel2.TabIndex = 63
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(56, 116)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(10, 15)
        Me.Label1.TabIndex = 64
        Me.Label1.Text = " "
        '
        'timor
        '
        Me.timor.Cursor = System.Windows.Forms.Cursors.Hand
        Me.timor.FlatAppearance.BorderSize = 0
        Me.timor.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red
        Me.timor.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.timor.Image = Global.uPDF_Joiner.My.Resources.Resources.timor_leste
        Me.timor.Location = New System.Drawing.Point(108, 46)
        Me.timor.Name = "timor"
        Me.timor.Size = New System.Drawing.Size(48, 35)
        Me.timor.TabIndex = 63
        Me.timor.TabStop = False
        Me.timor.UseVisualStyleBackColor = True
        '
        'lblang
        '
        Me.lblang.AutoSize = True
        Me.lblang.Location = New System.Drawing.Point(248, 392)
        Me.lblang.Name = "lblang"
        Me.lblang.Size = New System.Drawing.Size(41, 15)
        Me.lblang.TabIndex = 64
        Me.lblang.Text = "lblang"
        Me.lblang.Visible = False
        '
        'TextBox2
        '
        Me.TextBox2.BackColor = System.Drawing.SystemColors.Info
        Me.TextBox2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox2.Location = New System.Drawing.Point(325, 528)
        Me.TextBox2.Multiline = True
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.ReadOnly = True
        Me.TextBox2.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TextBox2.Size = New System.Drawing.Size(179, 51)
        Me.TextBox2.TabIndex = 65
        Me.TextBox2.TabStop = False
        '
        'CheckBox1
        '
        Me.CheckBox1.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.CheckBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox1.Location = New System.Drawing.Point(404, 5)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(104, 34)
        Me.CheckBox1.TabIndex = 66
        Me.CheckBox1.Text = "Set On Top" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.CheckBox1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AllowDrop = True
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(516, 591)
        Me.Controls.Add(Me.CheckBox1)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.lblang)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.text_lang)
        Me.Controls.Add(Me.txt_status2)
        Me.Controls.Add(Me.txtKey)
        Me.Controls.Add(Me.lbHWID)
        Me.Controls.Add(Me.lbtrial)
        Me.Controls.Add(Me.txt_settings)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.g_compression)
        Me.Controls.Add(Me.g_options)
        Me.Controls.Add(Me.ToolStrip2)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.txt_status3)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MainMenuStrip = Me.MenuStrip1
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "uPDF Joiner 2.1"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.ToolStrip2.ResumeLayout(False)
        Me.ToolStrip2.PerformLayout()
        Me.g_options.ResumeLayout(False)
        Me.g_options.PerformLayout()
        Me.g_compression.ResumeLayout(False)
        Me.g_compression.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents btn_remove As System.Windows.Forms.ToolStripButton
    Friend WithEvents btn_clear As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStrip2 As System.Windows.Forms.ToolStrip
    Friend WithEvents btn_addpdf As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents g_options As System.Windows.Forms.GroupBox
    Friend WithEvents chk_watermark As System.Windows.Forms.CheckBox
    Friend WithEvents chk_protect As System.Windows.Forms.CheckBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents g_compression As System.Windows.Forms.GroupBox
    Friend WithEvents rc_best As System.Windows.Forms.RadioButton
    Friend WithEvents rc_default As System.Windows.Forms.RadioButton
    Friend WithEvents rc_no As System.Windows.Forms.RadioButton
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents txt_status As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents MergeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AddFilesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MergeToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExtractToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SplitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RemoveToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RemoveToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ClearToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents txt_settings As System.Windows.Forms.Label
    Friend WithEvents lbtrial As System.Windows.Forms.Label
    Friend WithEvents lbHWID As System.Windows.Forms.Label
    Friend WithEvents txtKey As System.Windows.Forms.TextBox
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents btn_help As System.Windows.Forms.ToolStripSplitButton
    Friend WithEvents mnu_content As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnu_registration As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents mnu_about As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents txt_status2 As System.Windows.Forms.Label
    Friend WithEvents btn_save As System.Windows.Forms.ToolStripButton
    Friend WithEvents txt_status3 As System.Windows.Forms.TextBox
    Friend WithEvents usa As System.Windows.Forms.Button
    Friend WithEvents indo As System.Windows.Forms.Button
    Friend WithEvents th As System.Windows.Forms.Button
    Friend WithEvents text_lang As System.Windows.Forms.Label
    Friend WithEvents jp As System.Windows.Forms.Button
    Friend WithEvents ph As System.Windows.Forms.Button
    Friend WithEvents viet As System.Windows.Forms.Button
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents lblang As System.Windows.Forms.Label
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents ContributeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents timor As System.Windows.Forms.Button
    Friend WithEvents Pagess As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Filename As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents filesize As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents filepath As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents btn_Extract As System.Windows.Forms.ToolStripButton
    Friend WithEvents btn_Split As System.Windows.Forms.ToolStripButton
    Friend WithEvents CheckBox1 As System.Windows.Forms.CheckBox

End Class
