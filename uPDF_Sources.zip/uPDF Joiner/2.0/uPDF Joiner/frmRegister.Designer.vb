﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmRegister
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmRegister))
        Me.reg_id = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.btn_copy = New System.Windows.Forms.Button()
        Me.reg_key = New System.Windows.Forms.Label()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.btn_reg = New System.Windows.Forms.Button()
        Me.btn_close = New System.Windows.Forms.Button()
        Me.reg_buyreg = New System.Windows.Forms.Label()
        Me.reg_buyreg1 = New System.Windows.Forms.Label()
        Me.btn_paypal = New System.Windows.Forms.Button()
        Me.reg_afterpurchase = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.reg_info = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'reg_id
        '
        Me.reg_id.AutoSize = True
        Me.reg_id.Location = New System.Drawing.Point(12, 9)
        Me.reg_id.Name = "reg_id"
        Me.reg_id.Size = New System.Drawing.Size(77, 13)
        Me.reg_id.TabIndex = 0
        Me.reg_id.Text = "Registration ID"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(12, 25)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ReadOnly = True
        Me.TextBox1.Size = New System.Drawing.Size(226, 20)
        Me.TextBox1.TabIndex = 1
        Me.TextBox1.TabStop = False
        Me.TextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btn_copy
        '
        Me.btn_copy.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_copy.Image = Global.uPDF_Joiner.My.Resources.Resources.copied
        Me.btn_copy.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_copy.Location = New System.Drawing.Point(244, 25)
        Me.btn_copy.Name = "btn_copy"
        Me.btn_copy.Size = New System.Drawing.Size(63, 21)
        Me.btn_copy.TabIndex = 2
        Me.btn_copy.TabStop = False
        Me.btn_copy.Text = "&Copy"
        Me.btn_copy.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btn_copy.UseVisualStyleBackColor = True
        '
        'reg_key
        '
        Me.reg_key.AutoSize = True
        Me.reg_key.Location = New System.Drawing.Point(9, 191)
        Me.reg_key.Name = "reg_key"
        Me.reg_key.Size = New System.Drawing.Size(90, 13)
        Me.reg_key.TabIndex = 3
        Me.reg_key.Text = "Registration Key :"
        '
        'TextBox2
        '
        Me.TextBox2.BackColor = System.Drawing.SystemColors.Info
        Me.TextBox2.Location = New System.Drawing.Point(9, 207)
        Me.TextBox2.Multiline = True
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TextBox2.Size = New System.Drawing.Size(260, 67)
        Me.TextBox2.TabIndex = 4
        '
        'Button2
        '
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.ForeColor = System.Drawing.SystemColors.Control
        Me.Button2.Image = Global.uPDF_Joiner.My.Resources.Resources.bfolder
        Me.Button2.Location = New System.Drawing.Point(275, 207)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(32, 28)
        Me.Button2.TabIndex = 5
        Me.Button2.TabStop = False
        Me.Button2.UseVisualStyleBackColor = True
        '
        'btn_reg
        '
        Me.btn_reg.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_reg.Image = Global.uPDF_Joiner.My.Resources.Resources.key24
        Me.btn_reg.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_reg.Location = New System.Drawing.Point(9, 280)
        Me.btn_reg.Name = "btn_reg"
        Me.btn_reg.Size = New System.Drawing.Size(99, 32)
        Me.btn_reg.TabIndex = 6
        Me.btn_reg.Text = "Register"
        Me.btn_reg.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btn_reg.UseVisualStyleBackColor = True
        '
        'btn_close
        '
        Me.btn_close.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_close.Location = New System.Drawing.Point(114, 280)
        Me.btn_close.Name = "btn_close"
        Me.btn_close.Size = New System.Drawing.Size(96, 32)
        Me.btn_close.TabIndex = 7
        Me.btn_close.Text = "&Close"
        Me.btn_close.UseVisualStyleBackColor = True
        '
        'reg_buyreg
        '
        Me.reg_buyreg.AutoSize = True
        Me.reg_buyreg.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.reg_buyreg.Location = New System.Drawing.Point(12, 52)
        Me.reg_buyreg.Name = "reg_buyreg"
        Me.reg_buyreg.Size = New System.Drawing.Size(125, 13)
        Me.reg_buyreg.TabIndex = 8
        Me.reg_buyreg.Text = "Buy Registration Key"
        '
        'reg_buyreg1
        '
        Me.reg_buyreg1.AutoSize = True
        Me.reg_buyreg1.Location = New System.Drawing.Point(12, 67)
        Me.reg_buyreg1.Name = "reg_buyreg1"
        Me.reg_buyreg1.Size = New System.Drawing.Size(159, 13)
        Me.reg_buyreg1.TabIndex = 9
        Me.reg_buyreg1.Text = "for 1 Device / Lifetime - $5 USD"
        '
        'btn_paypal
        '
        Me.btn_paypal.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btn_paypal.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_paypal.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn_paypal.Image = Global.uPDF_Joiner.My.Resources.Resources.paypal
        Me.btn_paypal.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_paypal.Location = New System.Drawing.Point(226, 55)
        Me.btn_paypal.Name = "btn_paypal"
        Me.btn_paypal.Size = New System.Drawing.Size(81, 25)
        Me.btn_paypal.TabIndex = 11
        Me.btn_paypal.Text = "Buy Now"
        Me.btn_paypal.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btn_paypal.UseVisualStyleBackColor = False
        '
        'reg_afterpurchase
        '
        Me.reg_afterpurchase.AutoSize = True
        Me.reg_afterpurchase.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.reg_afterpurchase.Location = New System.Drawing.Point(12, 89)
        Me.reg_afterpurchase.Name = "reg_afterpurchase"
        Me.reg_afterpurchase.Size = New System.Drawing.Size(97, 13)
        Me.reg_afterpurchase.TabIndex = 12
        Me.reg_afterpurchase.Text = "After purchase?"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Panel1.Location = New System.Drawing.Point(12, 187)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(295, 1)
        Me.Panel1.TabIndex = 14
        '
        'reg_info
        '
        Me.reg_info.BackColor = System.Drawing.SystemColors.Info
        Me.reg_info.Location = New System.Drawing.Point(12, 105)
        Me.reg_info.Multiline = True
        Me.reg_info.Name = "reg_info"
        Me.reg_info.ReadOnly = True
        Me.reg_info.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.reg_info.Size = New System.Drawing.Size(295, 80)
        Me.reg_info.TabIndex = 15
        Me.reg_info.TabStop = False
        Me.reg_info.Text = resources.GetString("reg_info.Text")
        '
        'frmRegister
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(318, 321)
        Me.ControlBox = False
        Me.Controls.Add(Me.reg_info)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.reg_afterpurchase)
        Me.Controls.Add(Me.btn_paypal)
        Me.Controls.Add(Me.reg_buyreg1)
        Me.Controls.Add(Me.reg_buyreg)
        Me.Controls.Add(Me.btn_close)
        Me.Controls.Add(Me.btn_reg)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.reg_key)
        Me.Controls.Add(Me.btn_copy)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.reg_id)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "frmRegister"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Register uPDF Joiner Pro"
        Me.TopMost = True
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents reg_id As System.Windows.Forms.Label
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents btn_copy As System.Windows.Forms.Button
    Friend WithEvents reg_key As System.Windows.Forms.Label
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents btn_reg As System.Windows.Forms.Button
    Friend WithEvents btn_close As System.Windows.Forms.Button
    Friend WithEvents reg_buyreg As System.Windows.Forms.Label
    Friend WithEvents reg_buyreg1 As System.Windows.Forms.Label
    Friend WithEvents btn_paypal As System.Windows.Forms.Button
    Friend WithEvents reg_afterpurchase As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents reg_info As System.Windows.Forms.TextBox
End Class
