﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmContribute
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.con_text1 = New System.Windows.Forms.Label()
        Me.con_link = New System.Windows.Forms.LinkLabel()
        Me.con_text2 = New System.Windows.Forms.Label()
        Me.con_notes = New System.Windows.Forms.Label()
        Me.con_text3 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'con_text1
        '
        Me.con_text1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.con_text1.Location = New System.Drawing.Point(12, 9)
        Me.con_text1.Name = "con_text1"
        Me.con_text1.Size = New System.Drawing.Size(305, 71)
        Me.con_text1.TabIndex = 0
        Me.con_text1.Text = "Help us improve or add localization for uPDF Joiner to your language. please down" & _
            "load the language master file from the link below and convert it to your languag" & _
            "e."
        '
        'con_link
        '
        Me.con_link.AutoSize = True
        Me.con_link.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.con_link.Location = New System.Drawing.Point(12, 80)
        Me.con_link.Name = "con_link"
        Me.con_link.Size = New System.Drawing.Size(160, 13)
        Me.con_link.TabIndex = 1
        Me.con_link.TabStop = True
        Me.con_link.Text = "Download Language Master file."
        '
        'con_text2
        '
        Me.con_text2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.con_text2.Location = New System.Drawing.Point(12, 105)
        Me.con_text2.Name = "con_text2"
        Me.con_text2.Size = New System.Drawing.Size(312, 59)
        Me.con_text2.TabIndex = 2
        Me.con_text2.Text = "Use a program like NotePad or other text editor to convert it to your language. (" & _
            "no need to understand scripting language, because this master file has a simplif" & _
            "ied format)."
        '
        'con_notes
        '
        Me.con_notes.AutoSize = True
        Me.con_notes.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.con_notes.Location = New System.Drawing.Point(12, 164)
        Me.con_notes.Name = "con_notes"
        Me.con_notes.Size = New System.Drawing.Size(44, 13)
        Me.con_notes.TabIndex = 3
        Me.con_notes.Text = "Notes:"
        '
        'con_text3
        '
        Me.con_text3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.con_text3.Location = New System.Drawing.Point(12, 177)
        Me.con_text3.Name = "con_text3"
        Me.con_text3.Size = New System.Drawing.Size(312, 50)
        Me.con_text3.TabIndex = 4
        Me.con_text3.Text = "Don't forget to change [translator] and [language_name] to your name and the name" & _
            " of your language."
        '
        'frmContribute
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(329, 248)
        Me.Controls.Add(Me.con_text3)
        Me.Controls.Add(Me.con_notes)
        Me.Controls.Add(Me.con_text2)
        Me.Controls.Add(Me.con_link)
        Me.Controls.Add(Me.con_text1)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "frmContribute"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Contribute"
        Me.TopMost = True
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents con_text1 As System.Windows.Forms.Label
    Friend WithEvents con_link As System.Windows.Forms.LinkLabel
    Friend WithEvents con_text2 As System.Windows.Forms.Label
    Friend WithEvents con_notes As System.Windows.Forms.Label
    Friend WithEvents con_text3 As System.Windows.Forms.Label
End Class
