﻿Module lang

    Private LocalizationDict As New Dictionary(Of String, String)

    ' Memuat pasangan key = value dari file ke dictionary
    Public Sub LoadLocalization(ByVal filePath As String)
        LocalizationDict.Clear()
        If System.IO.File.Exists(filePath) Then
            Dim lines() As String = System.IO.File.ReadAllLines(filePath)
            Dim i As Integer
            For i = 0 To lines.Length - 1
                If lines(i).Contains("=") Then
                    Dim parts() As String = lines(i).Split("="c)
                    If parts.Length = 2 Then
                        Dim key As String = parts(0).Trim()
                        Dim value As String = parts(1).Trim()
                        If Not LocalizationDict.ContainsKey(key) Then
                            LocalizationDict.Add(key, value)
                        End If
                    End If
                End If
            Next
        Else
            'MessageBox.Show("File tidak ditemukan: " & filePath)
        End If
    End Sub

    ' Mengatur teks kontrol di semua Form yang sedang terbuka
    Public Sub ApplyLocalizationToAllOpenForms()
        Dim i As Integer
        For i = 0 To Application.OpenForms.Count - 1
            ApplyLocalizationToControls(Application.OpenForms.Item(i))
        Next
    End Sub

    ' Rekursif menelusuri semua kontrol dalam 1 form
    Private Sub ApplyLocalizationToControls(ByVal parent As Control)
        Dim i As Integer
        For i = 0 To parent.Controls.Count - 1
            Dim ctrl As Control = parent.Controls.Item(i)
            If LocalizationDict.ContainsKey(ctrl.Name) Then
                ctrl.Text = LocalizationDict(ctrl.Name)
            End If
            If ctrl.HasChildren Then
                ApplyLocalizationToControls(ctrl)
            End If
        Next
    End Sub

    ' Untuk mengambil teks dari dictionary, misalnya untuk MsgBox
    Public Function GetLocalizedText(ByVal key As String) As String
        If LocalizationDict.ContainsKey(key) Then
            Return LocalizationDict(key)
        Else
            Return key
        End If
    End Function

End Module
