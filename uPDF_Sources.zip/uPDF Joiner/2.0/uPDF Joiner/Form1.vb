﻿Imports iTextSharp.text
Imports iTextSharp.text.pdf
Imports System.Threading
Imports System.IO
Imports System.Management

Public Class Form1
    Private mergeThread As Thread
    Public userpass As String
    Public ownerpass As String
    Public pagesinput As String
    Public aestype As Boolean = False

    Sub isfilempty()
        ' Check if DataGridView has any rows with data (excluding the new row if present)
        Dim hasData As Boolean = False
        For Each row As DataGridViewRow In DataGridView1.Rows
            If Not row.IsNewRow Then
                hasData = True
                Exit For
            End If
        Next

        ' Enable/disable controls based on whether there's data
        Button1.Enabled = hasData
        Button2.Enabled = hasData
        ToolStrip1.Enabled = hasData
        g_options.Enabled = hasData
        g_compression.Enabled = hasData
        DataGridView1.Enabled = hasData
        txt_status2.Visible = Not hasData

        ' Additional checks for specific buttons that require selection
        If hasData Then
            btn_remove.Enabled = (DataGridView1.CurrentRow IsNot Nothing AndAlso Not DataGridView1.CurrentRow.IsNewRow)
            btn_extract.Enabled = (DataGridView1.CurrentRow IsNot Nothing AndAlso Not DataGridView1.CurrentRow.IsNewRow)
            btn_split.Enabled = (DataGridView1.CurrentRow IsNot Nothing AndAlso Not DataGridView1.CurrentRow.IsNewRow)
            btn_save.Enabled = (DataGridView1.CurrentRow IsNot Nothing AndAlso Not DataGridView1.CurrentRow.IsNewRow)
            ' Enable move up/down buttons only if there's more than one valid row
            Dim validRowCount As Integer = DataGridView1.Rows.Count - If(DataGridView1.AllowUserToAddRows, 1, 0)
            Button1.Enabled = (validRowCount > 1 AndAlso DataGridView1.CurrentRow IsNot Nothing AndAlso DataGridView1.CurrentRow.Index > 0)
            Button2.Enabled = (validRowCount > 1 AndAlso DataGridView1.CurrentRow IsNot Nothing AndAlso DataGridView1.CurrentRow.Index < validRowCount - 1)
        Else
            btn_remove.Enabled = False
            btn_extract.Enabled = False
            btn_split.Enabled = False
            btn_save.Enabled = False
        End If
    End Sub
    Sub procek()
        Dim t As New Thread(AddressOf GetCpuIdThread)
        t.IsBackground = True
        t.Start()
    End Sub
    ' Thread Function
    Private Sub GetCpuIdThread()
        Dim cpuId As String = GetCpuId()
        ' Update UI dari thread harus pakai Invoke
        Me.Invoke(New MethodInvoker(Sub()
                                        lbHWID.Text = cpuId
                                        Try
                                            txtKey.Text = System.IO.File.ReadAllText(System.IO.Path.Combine(Application.StartupPath, "reg.key"))
                                            Dim input As String = lbHWID.Text.Trim
                                            Dim serial As String = txtKey.Text.Trim
                                            If input = "" Or serial = "" Then
                                                'MessageBox.Show("Isi kedua kolom terlebih dahulu!")
                                                Exit Sub
                                            End If
                                            Try
                                                Dim hashedInput As String = HashSHA256(input)
                                                Dim decryptedSerial As String = DecryptAES(serial)
                                                If hashedInput = decryptedSerial Then
                                                    lbtrial.Text = "Pro"

                                                    txt_status3.Text = vbNewLine & GetLocalizedText("x014")
                                                    Me.Text = "uPDF Joiner 2.1 PRO"
                                                    lbtrial.BackColor = Color.Turquoise
                                                    txt_status3.TextAlign = HorizontalAlignment.Center
                                                    mnu_registration.Visible = False
                                                Else
                                                    lbtrial.Text = "Trial"
                                                    lbtrial.BackColor = Color.MistyRose
                                                    txt_status3.Text = GetLocalizedText("x013")
                                                    txt_status3.TextAlign = HorizontalAlignment.Center
                                                    Me.Text = "uPDF Joiner 2.1 TRIAL"
                                                End If
                                            Catch ex As Exception
                                                lbtrial.Text = "Trial"
                                                lbtrial.BackColor = Color.MistyRose
                                                txt_status3.Text = GetLocalizedText("x013")
                                                txt_status3.TextAlign = HorizontalAlignment.Center
                                                Me.Text = "uPDF Joiner 2.1 TRIAL"
                                            End Try
                                        Catch ex As Exception
                                            lbtrial.Text = "Trial"
                                            lbtrial.BackColor = Color.MistyRose
                                            txt_status3.Text = GetLocalizedText("x013")
                                            txt_status3.TextAlign = HorizontalAlignment.Center
                                            Me.Text = "uPDF Joiner 2.1 TRIAL"
                                        End Try
                                        Panel4.Visible = False
                                    End Sub))
    End Sub

    ' Fungsi GetCpuId tetap seperti sebelumnya
    Private Function GetCpuId() As String
        Try
            Dim mc As New ManagementClass("win32_processor")
            Dim moc As ManagementObjectCollection = mc.GetInstances()
            For Each mo As ManagementObject In moc
                Return mo.Properties("ProcessorId").Value.ToString()
            Next
            Return "Unknown"
        Catch ex As Exception
            Return "Error: " & ex.Message
        End Try
    End Function

    Private Sub Form1_DragDrop(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles Me.DragDrop
        Dim files() As String = CType(e.Data.GetData(DataFormats.FileDrop), String())
        If files.Length = 0 Then Exit Sub

        Button1.Enabled = False
        PictureBox1.Image = My.Resources.loadproc
        txt_status.Text = GetLocalizedText("x018")



        Dim dragThread As New Thread(Sub() LoadPDFs(files))
        dragThread.IsBackground = True
        dragThread.Start()
    End Sub

    Private Sub Form1_DragEnter(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles Me.DragEnter
        If e.Data.GetDataPresent(DataFormats.FileDrop) Then
            e.Effect = DragDropEffects.Copy
        Else
            e.Effect = DragDropEffects.None
        End If
    End Sub
    Sub langset()
        DataGridView1.Columns(0).HeaderText = GetLocalizedText("x084")
        DataGridView1.Columns(1).HeaderText = GetLocalizedText("x085")
        DataGridView1.Columns(2).HeaderText = GetLocalizedText("x086")
        DataGridView1.Columns(3).HeaderText = GetLocalizedText("x087")
        btn_addpdf.Text = GetLocalizedText("x051")
        btn_save.Text = GetLocalizedText("x052")
        btn_help.Text = GetLocalizedText("x053")
        btn_Extract.Text = GetLocalizedText("x054")
        btn_Split.Text = GetLocalizedText("x055")
        btn_remove.Text = GetLocalizedText("x056")
        btn_clear.Text = GetLocalizedText("x057")
        TextBox1.Text = GetLocalizedText("x075")
        TextBox2.Text = GetLocalizedText("x094")
        txt_status.Text = GetLocalizedText("x017")
        If lbtrial.Text = "Pro" Then
            txt_status3.Text = vbNewLine & GetLocalizedText("x014")
        Else
            txt_status3.Text = GetLocalizedText("x013")
        End If
        txt_status2.Text = GetLocalizedText("x016")
        ContributeToolStripMenuItem.Text = GetLocalizedText("x095")
        mnu_content.Text = GetLocalizedText("x061")
        mnu_registration.Text = GetLocalizedText("x062")
        mnu_about.Text = GetLocalizedText("x063")
        CheckBox1.Text = GetLocalizedText("x102")
        g_options.Text = GetLocalizedText("x006")
        g_compression.Text = GetLocalizedText("x009")
        chk_watermark.Text = GetLocalizedText("x007")
        chk_protect.Text = GetLocalizedText("x008")
        rc_no.Text = GetLocalizedText("x010")
        rc_default.Text = GetLocalizedText("x011")
        rc_best.Text = GetLocalizedText("x012")
        text_lang.Text = GetLocalizedText("x093")
        txt_settings.Text = GetLocalizedText("x005")
    End Sub
    Sub changinglang()
        langset()
        isfilempty()
    End Sub
    Private Sub SetButtonState(ByVal clickedButton As Button)
        ' Aktifkan semua tombol terlebih dahulu
        usa.Enabled = True
        indo.Enabled = True
        jp.Enabled = True
        ph.Enabled = True
        th.Enabled = True
        viet.Enabled = True
        timor.Enabled = True

        ' Nonaktifkan tombol yang diklik
        clickedButton.Enabled = False
    End Sub
    Sub langsettings()
        lblang.Text = My.Settings.langset
        If lblang.Text = "en" Then
            LoadLocalization(Application.StartupPath & "\lang_en.dll")
            ApplyLocalizationToAllOpenForms()
            changinglang()
            SetButtonState(usa)
        ElseIf lblang.Text = "id" Then
            LoadLocalization(Application.StartupPath & "\lang_id.dll")
            ApplyLocalizationToAllOpenForms()
            changinglang()
            SetButtonState(indo)
        ElseIf lblang.Text = "jp" Then
            LoadLocalization(Application.StartupPath & "\lang_jp.dll")
            ApplyLocalizationToAllOpenForms()
            changinglang()
            SetButtonState(jp)
        ElseIf lblang.Text = "ph" Then
            LoadLocalization(Application.StartupPath & "\lang_ph.dll")
            ApplyLocalizationToAllOpenForms()
            changinglang()
            SetButtonState(ph)
        ElseIf lblang.Text = "th" Then
            LoadLocalization(Application.StartupPath & "\lang_th.dll")
            ApplyLocalizationToAllOpenForms()
            changinglang()
            SetButtonState(th)
        ElseIf lblang.Text = "vn" Then
            LoadLocalization(Application.StartupPath & "\lang_vn.dll")
            ApplyLocalizationToAllOpenForms()
            changinglang()
            SetButtonState(viet)
        ElseIf lblang.Text = "tl" Then
            LoadLocalization(Application.StartupPath & "\lang_tl.dll")
            ApplyLocalizationToAllOpenForms()
            changinglang()
            SetButtonState(timor)
        Else
            LoadLocalization(Application.StartupPath & "\lang_en.dll")
            ApplyLocalizationToAllOpenForms()
            changinglang()
            SetButtonState(usa)
        End If
    End Sub
    
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ApplyLocalizationToAllOpenForms()
        Me.Text = "uPDF Joiner 2.1"
        Me.Icon = My.Resources.favicon
        langset()
        langsettings()
        isfilempty()
        procek()
    End Sub
    Sub savewithpass()
        Dim sfd As New SaveFileDialog()
        sfd.Filter = "PDF Files|*.pdf"
        If sfd.ShowDialog = Windows.Forms.DialogResult.OK Then
            mergeThread = New Thread(Sub() GabungPDF(sfd.FileName))
            mergeThread.IsBackground = True
            mergeThread.Start()
            PictureBox1.Image = My.Resources.loadproc
            txt_status.Text = GetLocalizedText("x019")
            Button1.Enabled = False
            Button2.Enabled = False
            ToolStrip1.Enabled = False
            ToolStrip2.Enabled = False
            g_options.Enabled = False
            g_compression.Enabled = False
        End If
    End Sub

    Private Sub ToolStripButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)


    End Sub
    Private Sub TambahWatermark(ByVal inputFile As String, ByVal outputFile As String, ByVal watermarkText As String)
        Dim reader As New PdfReader(inputFile)
        Dim stamper As New PdfStamper(reader, New FileStream(outputFile, FileMode.Create))
        Dim total As Integer = reader.NumberOfPages
        Dim font As BaseFont = BaseFont.CreateFont(BaseFont.HELVETICA, BaseFont.CP1252, BaseFont.NOT_EMBEDDED)

        For i As Integer = 1 To total
            Dim pageSize As Rectangle = reader.GetPageSizeWithRotation(i)
            Dim centerX As Single = pageSize.Width / 2
            Dim centerY As Single = pageSize.Height / 2

            Dim over As PdfContentByte = stamper.GetOverContent(i)
            over.BeginText()
            over.SetFontAndSize(font, 50)
            over.SetColorFill(BaseColor.LIGHT_GRAY)
            ' Watermark di tengah, miring 45 derajat
            over.ShowTextAligned(PdfContentByte.ALIGN_CENTER, watermarkText, centerX, centerY, 45)
            over.EndText()
        Next

        stamper.Close()
        reader.Close()
    End Sub

    Private Function HitungTotalHalaman() As Integer
        Dim total As Integer = 0
        For Each row As DataGridViewRow In DataGridView1.Rows
            total += Val(row.Cells(0).Value)
        Next
        Return total
    End Function

    Private Sub GabungPDF(ByVal outputFile As String)
        Dim doc As New Document()
        Dim copy As New PdfCopy(doc, New FileStream(outputFile, FileMode.Create))
        doc.Open()

        For Each row As DataGridViewRow In DataGridView1.Rows
            Dim path As String = row.Cells(3).Value.ToString()
            Dim reader As PdfReader = Nothing
            Dim isEncrypted As Boolean = False

            ' Cek apakah terenkripsi
            Try
                reader = New PdfReader(path)
                isEncrypted = reader.IsEncrypted
                reader.Close()
            Catch ex As BadPasswordException
                isEncrypted = True
            Catch ex As Exception
                Invoke(Sub() MessageBox.Show(GetLocalizedText("x020") & path, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error))
                Continue For
            End Try

            If isEncrypted Then
                Dim success As Boolean = False
                Do
                    Dim password As String = ""
                    Invoke(Sub()
                               Dim frm As New frmEnterPassword()
                               frm.PDFPath = path
                               If frm.ShowDialog() = DialogResult.OK Then
                                   password = frm.PasswordInput
                               End If
                           End Sub)

                    If password = "" Then Exit Do

                    Try
                        reader = New PdfReader(path, System.Text.Encoding.Default.GetBytes(password))
                        For i As Integer = 1 To reader.NumberOfPages
                            copy.AddPage(copy.GetImportedPage(reader, i))
                            UpdateProgressBar()
                        Next
                        reader.Close()
                        success = True
                    Catch ex As BadPasswordException
                        Invoke(Sub() MessageBox.Show(GetLocalizedText("x023") & path, "x024", MessageBoxButtons.OK, MessageBoxIcon.Warning))
                    Catch ex As Exception
                        Invoke(Sub() MessageBox.Show(GetLocalizedText("x021") & path, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error))
                        Exit Do
                    End Try
                Loop Until success
            Else
                Try
                    reader = New PdfReader(path)
                    For i As Integer = 1 To reader.NumberOfPages
                        copy.AddPage(copy.GetImportedPage(reader, i))
                        UpdateProgressBar()
                    Next
                    reader.Close()
                Catch ex As Exception
                    Invoke(Sub() MessageBox.Show(GetLocalizedText("x021") & path, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error))
                End Try
            End If
        Next

        doc.Close()
        Invoke(Sub() AfterMergeProcessing(outputFile))
    End Sub
    Private Sub AfterMergeProcessing(ByVal outputFile As String)
        Dim tempFile As String = outputFile

        ' Watermark jika dipilih
        If chk_watermark.Checked Then
            Dim tempWatermark As String = Path.Combine(Path.GetDirectoryName(outputFile), "temp_001.pdf")
            TambahWatermark(tempFile, tempWatermark, TextBox1.Text)
            If File.Exists(tempFile) Then File.Delete(tempFile)
            tempFile = tempWatermark
        End If

        ' Proteksi jika dipilih
        If chk_protect.Checked Then
            Dim tempProtected As String = Path.Combine(Path.GetDirectoryName(outputFile), "temp_002.pdf")
            ProtectPDF(tempFile, tempProtected, userpass, ownerpass)
            If File.Exists(tempFile) Then File.Delete(tempFile)
            tempFile = tempProtected

            ' ✅ Jangan compress kalau sudah diproteksi (langsung selesai)
            If File.Exists(outputFile) Then File.Delete(outputFile)
            File.Move(tempFile, outputFile)
        Else
            ' Compress hanya kalau tidak diproteksi
            Dim tempCompressed As String = Path.Combine(Path.GetDirectoryName(outputFile), "temp_003.pdf")
            CompressPDF(tempFile, tempCompressed)
            If File.Exists(tempFile) Then File.Delete(tempFile)
            If File.Exists(outputFile) Then File.Delete(outputFile)
            File.Move(tempCompressed, outputFile)
        End If

        ' Update UI
        Invoke(Sub()
                   Button1.Enabled = True
                   Button2.Enabled = True
                   ToolStrip1.Enabled = True
                   ToolStrip2.Enabled = True
                   g_options.Enabled = True
                   g_compression.Enabled = True
                   txt_status.Text = GetLocalizedText("x025")
                   PictureBox1.Image = Nothing
                   Process.Start(outputFile)
               End Sub)
    End Sub

    Private Sub ProtectPDF(ByVal inputFile As String, ByVal outputFile As String, ByVal userPass As String, ByVal ownerPass As String)
        Dim reader As New iTextSharp.text.pdf.PdfReader(inputFile)
        Dim fs As New FileStream(outputFile, FileMode.Create)
        Dim stamper As New iTextSharp.text.pdf.PdfStamper(reader, fs)

        If aestype Then
            ' AES-128 dengan NO PERMISSION
            stamper.SetEncryption( _
              System.Text.Encoding.UTF8.GetBytes(userPass), _
              System.Text.Encoding.UTF8.GetBytes(ownerPass), _
              0, _
              iTextSharp.text.pdf.PdfWriter.ENCRYPTION_AES_128)
        Else
            ' AES-256 dengan NO PERMISSION
            stamper.SetEncryption( _
              System.Text.Encoding.UTF8.GetBytes(userPass), _
              System.Text.Encoding.UTF8.GetBytes(ownerPass), _
              -1, _
              iTextSharp.text.pdf.PdfWriter.ENCRYPTION_AES_256)
        End If

        stamper.Close()
        reader.Close()
        fs.Close()
    End Sub

    Private Sub CompressPDF(ByVal inputFile As String, ByVal outputFile As String)
        Dim reader As New PdfReader(inputFile)
        Dim fs As New FileStream(outputFile, FileMode.Create)
        Dim document As New Document()
        Dim copy As New PdfSmartCopy(document, fs)

        copy.SetFullCompression() ' ✅ Dipanggil di awal sebelum Open()

        document.Open()

        For i As Integer = 1 To reader.NumberOfPages
            copy.AddPage(copy.GetImportedPage(reader, i))
        Next

        document.Close()
        reader.Close()
        fs.Close()
    End Sub
    Private Sub UpdateProgressBar()
        'If ProgressBar1.InvokeRequired Then
        '    ProgressBar1.Invoke(New MethodInvoker(AddressOf UpdateProgressBar))
        'Else
        '    If ProgressBar1.Value < ProgressBar1.Maximum Then
        '        ProgressBar1.Value += 1
        '    End If
        'End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.ActiveControl = Nothing
        Dim idx As Integer = DataGridView1.CurrentRow.Index
        If idx > 0 Then
            Dim row As DataGridViewRow = DataGridView1.Rows(idx)
            DataGridView1.Rows.RemoveAt(idx)
            DataGridView1.Rows.Insert(idx - 1, row)
            DataGridView1.CurrentCell = DataGridView1.Rows(idx - 1).Cells(0)
            isfilempty()
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.ActiveControl = Nothing
        Dim idx As Integer = DataGridView1.CurrentRow.Index
        If idx < DataGridView1.Rows.Count - 1 Then
            Dim row As DataGridViewRow = DataGridView1.Rows(idx)
            DataGridView1.Rows.RemoveAt(idx)
            DataGridView1.Rows.Insert(idx + 1, row)
            DataGridView1.CurrentCell = DataGridView1.Rows(idx + 1).Cells(0)
            isfilempty()
        End If
    End Sub

    Private Sub ToolStripButton4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_remove.Click
        Me.ActiveControl = Nothing
        If DataGridView1.CurrentRow IsNot Nothing Then
            DataGridView1.Rows.Remove(DataGridView1.CurrentRow)
            isfilempty()
        End If
    End Sub
    Private loadThread As Thread

    Private Sub ToolStripButton6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_addpdf.Click
        Me.ActiveControl = Nothing
        Dim ofd As New OpenFileDialog()
        ofd.Filter = "PDF Files|*.pdf"
        ofd.Multiselect = True

        If ofd.ShowDialog = Windows.Forms.DialogResult.OK Then
            Button1.Enabled = False ' Disable tombol selama load
            PictureBox1.Image = My.Resources.loadproc
            txt_status.Text = GetLocalizedText("x018")
            Dim selectedFiles() As String = ofd.FileNames

            loadThread = New Thread(Sub() LoadPDFs(selectedFiles))
            loadThread.IsBackground = True
            loadThread.Start()
        End If
    End Sub
    Private Sub LoadPDFs(ByVal files As String())
        If lbtrial.Text = "Trial" Then
            ' ✅ Cek sebelum mulai, jika sudah penuh jangan lanjut
            Dim cancel As Boolean = False
            Invoke(Sub()
                       If DataGridView1.Rows.Count >= 20 Then
                           MessageBox.Show(GetLocalizedText("x026"), "File Limit", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                           Button1.Enabled = True
                           Button2.Enabled = True
                           ToolStrip1.Enabled = True
                           ToolStrip2.Enabled = True
                           g_options.Enabled = True
                           g_compression.Enabled = True
                           PictureBox1.Image = Nothing
                           txt_status.Text = GetLocalizedText("x017")
                           cancel = True
                       End If
                   End Sub)
            If cancel Then Exit Sub

            For Each filePath As String In files
                Dim currentFile As String = filePath

                ' ✅ Cek apakah sudah ada di DataGridView
                Dim fileExists As Boolean = False
                Invoke(Sub()
                           For Each row As DataGridViewRow In DataGridView1.Rows
                               If row.Cells(3).Value.ToString().ToLower() = currentFile.ToLower() Then
                                   fileExists = True
                                   Exit For
                               End If
                           Next
                       End Sub)
                If fileExists Then Continue For

                ' ✅ Cek apakah masih boleh ditambahkan
                Dim isLimitReached As Boolean = False
                Invoke(Sub()
                           If DataGridView1.Rows.Count >= 20 Then
                               MessageBox.Show(GetLocalizedText("x027"), "File Limit", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                               Button1.Enabled = True
                               Button2.Enabled = True
                               ToolStrip1.Enabled = True
                               ToolStrip2.Enabled = True
                               g_options.Enabled = True
                               g_compression.Enabled = True
                               PictureBox1.Image = Nothing
                               txt_status.Text = GetLocalizedText("x017")
                               isLimitReached = True
                           End If
                       End Sub)
                If isLimitReached Then Exit For

                ' ✅ Lanjut proses
                Dim fi As New FileInfo(currentFile)
                Dim reader As PdfReader = Nothing
                Dim isEncrypted As Boolean = False

                Try
                    reader = New PdfReader(currentFile)
                    isEncrypted = reader.IsEncrypted
                    reader.Close()
                Catch ex As BadPasswordException
                    isEncrypted = True
                Catch ex As Exception
                    Invoke(Sub() MessageBox.Show(GetLocalizedText("x020") & fi.Name, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error))
                    Continue For
                End Try

                If isEncrypted Then
                    Dim success As Boolean = False
                    Do
                        Dim passwordInput As String = Nothing

                        Invoke(Sub()
                                   Dim frm As New frmEnterPassword()
                                   frm.PDFPath = currentFile
                                   If frm.ShowDialog() = DialogResult.OK Then
                                       passwordInput = frm.PasswordInput
                                   End If
                               End Sub)

                        If String.IsNullOrEmpty(passwordInput) Then Exit Do

                        Try
                            reader = New PdfReader(currentFile, System.Text.Encoding.Default.GetBytes(passwordInput))
                            Dim pages As Integer = reader.NumberOfPages
                            reader.Close()

                            Invoke(Sub()
                                       If DataGridView1.Rows.Count < 20 Then
                                           DataGridView1.Rows.Add("(" & pages & ") " & GetLocalizedText("x028"), fi.Name, FormatFileSize(fi.Length), fi.FullName)
                                       Else
                                           MessageBox.Show(GetLocalizedText("x027"), "File Limit", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                                           Button1.Enabled = True
                                           Button2.Enabled = True
                                           ToolStrip1.Enabled = True
                                           ToolStrip2.Enabled = True
                                           g_options.Enabled = True
                                           g_compression.Enabled = True
                                           PictureBox1.Image = Nothing
                                           txt_status.Text = GetLocalizedText("x017")
                                           isfilempty()
                                       End If
                                   End Sub)
                            success = True
                        Catch ex As BadPasswordException
                            Invoke(Sub() MessageBox.Show(GetLocalizedText("x023") & fi.Name, "x024", MessageBoxButtons.OK, MessageBoxIcon.Warning))
                        Catch ex As Exception
                            'Invoke(Sub() MessageBox.Show("Failed to open file: " & fi.Name, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error))
                            Exit Do
                        End Try
                    Loop Until success
                Else
                    Try
                        reader = New PdfReader(currentFile)
                        Dim pages As Integer = reader.NumberOfPages
                        reader.Close()

                        Invoke(Sub()
                                   If DataGridView1.Rows.Count < 20 Then
                                       DataGridView1.Rows.Add("(" & pages & ") " & GetLocalizedText("x028"), fi.Name, FormatFileSize(fi.Length), fi.FullName)
                                   Else
                                       MessageBox.Show(GetLocalizedText("x027"), "File Limit", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                                       Button1.Enabled = True
                                       Button2.Enabled = True
                                       ToolStrip1.Enabled = True
                                       ToolStrip2.Enabled = True
                                       g_options.Enabled = True
                                       g_compression.Enabled = True
                                       PictureBox1.Image = Nothing
                                       txt_status.Text = GetLocalizedText("x017")
                                       isfilempty()
                                   End If
                               End Sub)
                    Catch ex As Exception
                        Invoke(Sub() MessageBox.Show(GetLocalizedText("x020") & fi.Name, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error))
                    End Try
                End If
            Next

            ' ✅ Aktifkan tombol kembali
            Invoke(Sub()
                       Button1.Enabled = True
                       Button2.Enabled = True
                       ToolStrip1.Enabled = True
                       ToolStrip2.Enabled = True
                       g_options.Enabled = True
                       g_compression.Enabled = True
                       PictureBox1.Image = Nothing
                       txt_status.Text = GetLocalizedText("x017")
                   End Sub)
        Else
            For Each filePath As String In files
                Dim currentFile As String = filePath ' Untuk menghindari warning lambda

                ' ✅ Cek apakah file sudah ada di DataGridView
                Dim fileExists As Boolean = False
                Invoke(Sub()
                           For Each row As DataGridViewRow In DataGridView1.Rows
                               If row.Cells(3).Value.ToString().ToLower() = currentFile.ToLower() Then
                                   fileExists = True
                                   Exit For
                               End If
                           Next
                       End Sub)

                If fileExists Then
                    ' Lewati jika duplikat
                    Continue For
                End If

                Dim fi As New FileInfo(currentFile)
                Dim reader As PdfReader = Nothing
                Dim isEncrypted As Boolean = False

                Try
                    reader = New PdfReader(currentFile)
                    isEncrypted = reader.IsEncrypted
                    reader.Close()
                Catch ex As BadPasswordException
                    isEncrypted = True
                Catch ex As Exception
                    Invoke(Sub() MessageBox.Show(GetLocalizedText("x020") & fi.Name, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error))
                    Continue For
                End Try

                If isEncrypted Then
                    Dim success As Boolean = False
                    Do
                        Dim passwordInput As String = Nothing

                        Invoke(Sub()
                                   Dim frm As New frmEnterPassword()
                                   frm.PDFPath = currentFile
                                   If frm.ShowDialog() = DialogResult.OK Then
                                       passwordInput = frm.PasswordInput
                                   End If
                               End Sub)

                        If String.IsNullOrEmpty(passwordInput) Then
                            Exit Do ' Batal
                        End If

                        Try
                            reader = New PdfReader(currentFile, System.Text.Encoding.Default.GetBytes(passwordInput))
                            Dim pages As Integer = reader.NumberOfPages
                            reader.Close()

                            Invoke(Sub()
                                       DataGridView1.Rows.Add("(" & pages & ") " & GetLocalizedText("x028"), fi.Name, FormatFileSize(fi.Length), fi.FullName)
                                       isfilempty()
                                   End Sub)
                            success = True
                        Catch ex As BadPasswordException
                            Invoke(Sub() MessageBox.Show(GetLocalizedText("x023") & fi.Name, GetLocalizedText("x024"), MessageBoxButtons.OK, MessageBoxIcon.Warning))
                        Catch ex As Exception
                            Invoke(Sub() MessageBox.Show(GetLocalizedText("x021") & fi.Name, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error))
                            Exit Do
                        End Try
                    Loop Until success
                Else
                    Try
                        reader = New PdfReader(currentFile)
                        Dim pages As Integer = reader.NumberOfPages
                        reader.Close()

                        Invoke(Sub()
                                   DataGridView1.Rows.Add("(" & pages & ") " & GetLocalizedText("x028"), fi.Name, FormatFileSize(fi.Length), fi.FullName)
                               End Sub)
                    Catch ex As Exception
                        Invoke(Sub() MessageBox.Show(GetLocalizedText("x020") & fi.Name, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error))
                    End Try
                End If
            Next

            ' Enable tombol kembali setelah selesai semua
            Invoke(Sub()
                       Button1.Enabled = True
                       Button2.Enabled = True
                       ToolStrip1.Enabled = True
                       ToolStrip2.Enabled = True
                       g_options.Enabled = True
                       g_compression.Enabled = True
                       PictureBox1.Image = Nothing
                       txt_status.Text = GetLocalizedText("x017")
                       isfilempty()
                   End Sub)
        End If

    End Sub
    Private Function FormatFileSize(ByVal bytes As Long) As String
        If bytes < 1024 Then Return bytes & " B"
        If bytes < 1048576 Then Return Format(bytes / 1024, "0.00") & " KB"
        If bytes < 1073741824 Then Return Format(bytes / 1048576, "0.00") & " MB"
        Return Format(bytes / 1073741824, "0.00") & " GB"
    End Function

    Private Sub CheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chk_watermark.CheckedChanged
        If chk_watermark.Checked Then
            TextBox1.Enabled = True
            TextBox1.Text = "uPDF Joiner"
        Else
            TextBox1.Enabled = False
            TextBox1.Text = GetLocalizedText("x029")
        End If
    End Sub

    Private Sub ExtractPages(ByVal inputFile As String, ByVal outputFile As String, ByVal pagesToExtract As List(Of Integer))
        Dim reader As New PdfReader(inputFile)
        Dim doc As New Document()
        Dim copy As New PdfCopy(doc, New FileStream(outputFile, FileMode.Create))
        doc.Open()

        For Each pageNum As Integer In pagesToExtract
            If pageNum >= 1 And pageNum <= reader.NumberOfPages Then
                copy.AddPage(copy.GetImportedPage(reader, pageNum))
            End If
        Next

        doc.Close()
        reader.Close()
    End Sub
    Private extractThread As Thread

    Sub extractpages()
        If DataGridView1.CurrentRow Is Nothing Then Exit Sub

        Dim filePath As String = DataGridView1.CurrentRow.Cells(3).Value.ToString()
        Dim sfd As New SaveFileDialog()
        sfd.Filter = "PDF Files|*.pdf"

        If sfd.ShowDialog = Windows.Forms.DialogResult.OK Then
            Dim pageInput As String = pagesinput
            If String.IsNullOrEmpty(pageInput) Then Exit Sub

            Dim pages As New List(Of Integer)
            For Each p In pageInput.Split(","c)
                If IsNumeric(p) Then pages.Add(CInt(p))
            Next

            ' Disable tombol dan mulai thread
            Button1.Enabled = False
            Button2.Enabled = False
            ToolStrip1.Enabled = False
            ToolStrip2.Enabled = False
            g_options.Enabled = False
            g_compression.Enabled = False
            PictureBox1.Image = My.Resources.loadproc
            txt_status.Text = GetLocalizedText("x030") & " (" & pageInput & ")"

            extractThread = New Thread(Sub()
                                           Try
                                               Dim passwordBytes() As Byte = Nothing

                                               ' Cek apakah PDF terenkripsi
                                               Dim isEncrypted As Boolean = False
                                               Try
                                                   Dim testReader As New PdfReader(filePath)
                                                   isEncrypted = testReader.IsEncrypted
                                                   testReader.Close()
                                               Catch ex As BadPasswordException
                                                   isEncrypted = True
                                               End Try

                                               If isEncrypted Then
                                                   Dim success As Boolean = False
                                                   Do
                                                       Dim inputPass As String = ""
                                                       Invoke(Sub()
                                                                  Dim frm As New frmEnterPassword()
                                                                  frm.PDFPath = filePath
                                                                  If frm.ShowDialog() = DialogResult.OK Then
                                                                      inputPass = frm.PasswordInput
                                                                  End If
                                                              End Sub)

                                                       If inputPass = "" Then Exit Do

                                                       Try
                                                           Dim testReader2 As New PdfReader(filePath, System.Text.Encoding.Default.GetBytes(inputPass))
                                                           testReader2.Close()
                                                           passwordBytes = System.Text.Encoding.Default.GetBytes(inputPass)
                                                           success = True
                                                       Catch ex As BadPasswordException
                                                           Invoke(Sub() MessageBox.Show(GetLocalizedText("x024"), GetLocalizedText("x024")))
                                                       End Try
                                                   Loop Until success

                                                   If Not success Then Exit Sub
                                               End If

                                               ' Eksekusi Extract dengan password kalau ada
                                               Invoke(Sub() txt_status.Text = GetLocalizedText("x031"))

                                               If passwordBytes IsNot Nothing Then
                                                   ExtractPagesWithPassword(filePath, sfd.FileName, pages, passwordBytes)
                                               Else
                                                   ExtractPages(filePath, sfd.FileName, pages)
                                               End If

                                           Catch ex As Exception
                                               Invoke(Sub() MessageBox.Show(GetLocalizedText("x032") & ex.Message, "Error"))
                                           Finally
                                               Invoke(Sub()
                                                          Button1.Enabled = True
                                                          Button2.Enabled = True
                                                          ToolStrip1.Enabled = True
                                                          ToolStrip2.Enabled = True
                                                          g_options.Enabled = True
                                                          g_compression.Enabled = True
                                                          PictureBox1.Image = Nothing
                                                          txt_status.Text = GetLocalizedText("x033")
                                                          Process.Start(sfd.FileName)
                                                      End Sub)
                                           End Try
                                       End Sub)
            extractThread.IsBackground = True
            extractThread.Start()
        End If
    End Sub
    Private Sub ExtractPagesWithPassword(ByVal inputFile As String, ByVal outputFile As String, ByVal pagesToExtract As List(Of Integer), ByVal password As Byte())
        Dim reader As New PdfReader(inputFile, password)
        Dim doc As New Document()
        Dim copy As New PdfCopy(doc, New FileStream(outputFile, FileMode.Create))
        doc.Open()

        For Each pageNum As Integer In pagesToExtract
            If pageNum >= 1 And pageNum <= reader.NumberOfPages Then
                copy.AddPage(copy.GetImportedPage(reader, pageNum))
            End If
        Next

        doc.Close()
        reader.Close()
    End Sub

    Private Sub SplitPDFWithPasswordPrompt(ByVal inputFile As String, ByVal outputFolder As String)
        Dim fi As New FileInfo(inputFile)
        Dim reader As PdfReader = Nothing
        Dim isEncrypted As Boolean = False

        Try
            reader = New PdfReader(inputFile)
            isEncrypted = reader.IsEncrypted
            reader.Close()
        Catch ex As BadPasswordException
            isEncrypted = True
        Catch ex As Exception
            Invoke(Sub() MessageBox.Show(GetLocalizedText("x020") & fi.Name, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error))
            Exit Sub
        End Try

        If isEncrypted Then
            Dim success As Boolean = False
            Do
                Dim passwordInput As String = Nothing

                Invoke(Sub()
                           Dim frm As New frmEnterPassword()
                           frm.PDFPath = inputFile
                           If frm.ShowDialog() = DialogResult.OK Then
                               passwordInput = frm.PasswordInput
                           End If
                       End Sub)

                If String.IsNullOrEmpty(passwordInput) Then
                    Exit Do ' Batal
                End If

                Try
                    reader = New PdfReader(inputFile, System.Text.Encoding.Default.GetBytes(passwordInput))
                    ExtractSplitPages(reader, outputFolder, fi.Name)
                    success = True
                Catch ex As BadPasswordException
                    Invoke(Sub() MessageBox.Show(GetLocalizedText("x023") & fi.Name, GetLocalizedText("x024"), MessageBoxButtons.OK, MessageBoxIcon.Warning))
                Catch ex As Exception
                    Invoke(Sub() MessageBox.Show(GetLocalizedText("x021") & fi.Name, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error))
                    Exit Do
                End Try
            Loop Until success
        Else
            Try
                reader = New PdfReader(inputFile)
                ExtractSplitPages(reader, outputFolder, fi.Name)
            Catch ex As Exception
                Invoke(Sub() MessageBox.Show(GetLocalizedText("x021") & fi.Name, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error))
            End Try
        End If
    End Sub

    Private Sub ExtractSplitPages(ByVal reader As PdfReader, ByVal outputFolder As String, ByVal originalFileName As String)
        Dim baseName As String = System.IO.Path.GetFileNameWithoutExtension(originalFileName)

        For i As Integer = 1 To reader.NumberOfPages
            Dim doc As New Document()
            Dim outputFile As String = System.IO.Path.Combine(outputFolder, baseName & "_split_" & Format(i, "00") & ".pdf")
            Dim copy As New PdfCopy(doc, New FileStream(outputFile, FileMode.Create))
            doc.Open()
            copy.AddPage(copy.GetImportedPage(reader, i))
            doc.Close()
        Next

        reader.Close()
    End Sub

    Private splitThread As Thread

    Private Sub ToolStripButton5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_clear.Click
        Me.ActiveControl = Nothing
        If DataGridView1.Rows.Count > 0 Then
            ' Remove all rows except the new row if AllowUserToAddRows is true
            If DataGridView1.AllowUserToAddRows Then
                While DataGridView1.Rows.Count > 1
                    DataGridView1.Rows.RemoveAt(0)
                End While
            Else
                DataGridView1.Rows.Clear()
            End If
            isfilempty()
        End If
    End Sub

    Private Sub AddFilesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddFilesToolStripMenuItem.Click
        btn_addpdf.PerformClick()
    End Sub

    Private Sub MergeToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MergeToolStripMenuItem1.Click
        btn_save.PerformClick()
    End Sub

    Private Sub ExtractToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExtractToolStripMenuItem.Click
        btn_extract.PerformClick()
    End Sub

    Private Sub SplitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SplitToolStripMenuItem.Click
        btn_split.PerformClick()
    End Sub

    Private Sub RemoveToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RemoveToolStripMenuItem1.Click
        btn_remove.PerformClick()
    End Sub

    Private Sub ClearToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClearToolStripMenuItem.Click
        btn_clear.PerformClick()
    End Sub

    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs)
        frmRegister.Show()
    End Sub

    Private Sub ToolStripSplitButton1_ButtonClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_help.ButtonClick
        btn_help.ShowDropDown()
    End Sub

    Private Sub DataGridView1_CurrentCellChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DataGridView1.CurrentCellChanged
        isfilempty()
    End Sub

    Private Sub DataGridView1_DragDrop(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles DataGridView1.DragDrop
        Dim files() As String = CType(e.Data.GetData(DataFormats.FileDrop), String())
        If files.Length = 0 Then Exit Sub

        Button1.Enabled = False
        PictureBox1.Image = My.Resources.loadproc
        txt_status.Text = GetLocalizedText("x018")

        Dim dragThread As New Thread(Sub() LoadPDFs(files))
        dragThread.IsBackground = True
        dragThread.Start()
    End Sub


    Private Sub DataGridView1_DragEnter(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles DataGridView1.DragEnter
        If e.Data.GetDataPresent(DataFormats.FileDrop) Then
            e.Effect = DragDropEffects.Copy
        Else
            e.Effect = DragDropEffects.None
        End If
    End Sub

    Private Sub lbdragdrop_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_status2.Click

    End Sub

    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub BuyRegistrationKeyToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnu_registration.Click
        frmRegister.Show()
    End Sub

    Private Sub ContentToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnu_content.Click
        If usa.Enabled = False Then
            Try
                Process.Start(System.IO.Path.Combine(Application.StartupPath, "help_en.txt"))
            Catch ex As Exception

            End Try
        ElseIf indo.Enabled = False Then
            Try
                Process.Start(System.IO.Path.Combine(Application.StartupPath, "help_id.txt"))
            Catch ex As Exception

            End Try
        ElseIf jp.Enabled = False Then
            Try
                Process.Start(System.IO.Path.Combine(Application.StartupPath, "help_jp.txt"))
            Catch ex As Exception

            End Try
        ElseIf ph.Enabled = False Then
            Try
                Process.Start(System.IO.Path.Combine(Application.StartupPath, "help_ph.txt"))
            Catch ex As Exception

            End Try
        ElseIf th.Enabled = False Then
            Try
                Process.Start(System.IO.Path.Combine(Application.StartupPath, "help_th.txt"))
            Catch ex As Exception

            End Try
        ElseIf timor.Enabled = False Then
            Try
                Process.Start(System.IO.Path.Combine(Application.StartupPath, "help_tl.txt"))
            Catch ex As Exception

            End Try
        ElseIf viet.Enabled = False Then
            Try
                Process.Start(System.IO.Path.Combine(Application.StartupPath, "help_vn.txt"))
            Catch ex As Exception

            End Try
        End If
       
    End Sub

    Private Sub AboutToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnu_about.Click
        frmAbout.Show()
    End Sub

    Private Sub ToolStripButton7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_save.Click
        Me.ActiveControl = Nothing
        If DataGridView1.Rows.Count = 0 Then
            MessageBox.Show(GetLocalizedText("x037"), "Warning")
            Exit Sub
        End If
        If chk_protect.Checked Then
            frmPassword.Show()
        Else
            Dim sfd As New SaveFileDialog()
            sfd.Filter = "PDF Files|*.pdf"
            If sfd.ShowDialog = Windows.Forms.DialogResult.OK Then


                mergeThread = New Thread(Sub() GabungPDF(sfd.FileName))

                mergeThread.IsBackground = True
                mergeThread.Start()
                PictureBox1.Image = My.Resources.loadproc
                txt_status.Text = GetLocalizedText("x019")
                Button1.Enabled = False
                Button2.Enabled = False
                ToolStrip1.Enabled = False
                ToolStrip2.Enabled = False
                g_options.Enabled = False
                g_compression.Enabled = False
            End If
        End If
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles usa.Click
        Me.ActiveControl = Nothing
        LoadLocalization(Application.StartupPath & "\lang_en.dll")
        ApplyLocalizationToAllOpenForms()
        changinglang()
        SetButtonState(usa)
        My.Settings.langset = "en"
        My.Settings.Save()
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles indo.Click
        Me.ActiveControl = Nothing
        LoadLocalization(Application.StartupPath & "\lang_id.dll")
        ApplyLocalizationToAllOpenForms()
        changinglang()
        SetButtonState(indo)
        My.Settings.langset = "id"
        My.Settings.Save()
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles th.Click
        Me.ActiveControl = Nothing
        LoadLocalization(Application.StartupPath & "\lang_th.dll")
        ApplyLocalizationToAllOpenForms()
        changinglang()
        SetButtonState(th)
        My.Settings.langset = "th"
        My.Settings.Save()
    End Sub

    Private Sub viet_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles viet.Click
        Me.ActiveControl = Nothing
        LoadLocalization(Application.StartupPath & "\lang_vn.dll")
        ApplyLocalizationToAllOpenForms()
        changinglang()
        SetButtonState(viet)
        My.Settings.langset = "vn"
        My.Settings.Save()
    End Sub

    Private Sub jp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles jp.Click
        Me.ActiveControl = Nothing
        LoadLocalization(Application.StartupPath & "\lang_jp.dll")
        ApplyLocalizationToAllOpenForms()
        changinglang()
        SetButtonState(jp)
        My.Settings.langset = "jp"
        My.Settings.Save()
    End Sub

    Private Sub ph_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ph.Click
        Me.ActiveControl = Nothing
        LoadLocalization(Application.StartupPath & "\lang_ph.dll")
        ApplyLocalizationToAllOpenForms()
        changinglang()
        SetButtonState(ph)
        My.Settings.langset = "ph"
        My.Settings.Save()
    End Sub

    Private Sub ContributeToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ContributeToolStripMenuItem.Click
        frmContribute.Show()
    End Sub

  
    Private Sub timor_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles timor.Click
        Me.ActiveControl = Nothing
        LoadLocalization(Application.StartupPath & "\lang_tl.dll")
        ApplyLocalizationToAllOpenForms()
        changinglang()
        SetButtonState(timor)
        My.Settings.langset = "tl"
        My.Settings.Save()
    End Sub
    Private Sub ToolStripButton2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Split.Click
        Me.ActiveControl = Nothing
        If DataGridView1.CurrentRow Is Nothing Then Exit Sub

        Dim filePath As String = DataGridView1.CurrentRow.Cells(3).Value.ToString()

        Dim fbd As New FolderBrowserDialog()
        If fbd.ShowDialog = Windows.Forms.DialogResult.OK Then
            Button1.Enabled = False
            Button2.Enabled = False
            ToolStrip1.Enabled = False
            ToolStrip2.Enabled = False
            g_options.Enabled = False
            g_compression.Enabled = False
            PictureBox1.Image = My.Resources.loadproc
            txt_status.Text = GetLocalizedText("x034") & " (" & filePath & ")..."
            splitThread = New Thread(Sub()
                                         Try
                                             SplitPDFWithPasswordPrompt(filePath, fbd.SelectedPath)
                                         Catch ex As Exception
                                             Invoke(Sub() MessageBox.Show(GetLocalizedText("x035") & ex.Message, "Error"))
                                         Finally

                                             Invoke(Sub()
                                                        Button1.Enabled = True
                                                        Button2.Enabled = True
                                                        ToolStrip1.Enabled = True
                                                        ToolStrip2.Enabled = True
                                                        g_options.Enabled = True
                                                        g_compression.Enabled = True
                                                        PictureBox1.Image = Nothing
                                                        txt_status.Text = GetLocalizedText("x036")
                                                        Process.Start(fbd.SelectedPath)
                                                    End Sub)
                                         End Try
                                     End Sub)
            splitThread.IsBackground = True
            splitThread.Start()
        End If
    End Sub

    Private Sub ToolStripButton1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Extract.Click
        Me.ActiveControl = Nothing
        If DataGridView1.CurrentRow Is Nothing Then Exit Sub

        Dim filePath As String = DataGridView1.CurrentRow.Cells(3).Value.ToString()
        Dim fi As New FileInfo(filePath)
        Dim reader As PdfReader = Nothing
        Dim pages As Integer = 0
        Dim success As Boolean = False

        Try
            ' Coba baca tanpa password
            reader = New PdfReader(filePath)
            pages = reader.NumberOfPages
            reader.Close()
            success = True
        Catch ex As BadPasswordException
            ' Jika gagal karena password, minta lewat dialog
            Do
                Dim frm As New frmEnterPassword()
                frm.PDFPath = filePath
                If frm.ShowDialog() = DialogResult.OK Then
                    Try
                        reader = New PdfReader(filePath, System.Text.Encoding.Default.GetBytes(frm.PasswordInput))
                        pages = reader.NumberOfPages
                        reader.Close()
                        success = True
                        Exit Do
                    Catch ex2 As BadPasswordException
                        MessageBox.Show(GetLocalizedText("x023") & fi.Name, GetLocalizedText("x024"), MessageBoxButtons.OK, MessageBoxIcon.Warning)
                    End Try
                Else
                    Exit Sub ' User cancel
                End If
            Loop
        Catch ex As Exception
            MessageBox.Show(GetLocalizedText("x020") & fi.Name & vbCrLf & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End Try

        If success Then
            frmExtractPages.TextBox1.Text = fi.Name
            frmExtractPages.TextBox2.Text = fi.Directory.FullName
            frmExtractPages.TextBox3.Text = fi.CreationTime
            frmExtractPages.TextBox4.Text = FormatFileSize(fi.Length)
            frmExtractPages.TextBox5.Text = pages
            frmExtractPages.Show()
        End If
    End Sub

    Private Sub CheckBox1_CheckedChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked Then
            Me.TopMost = True
        Else
            Me.TopMost = False
        End If
    End Sub
End Class
