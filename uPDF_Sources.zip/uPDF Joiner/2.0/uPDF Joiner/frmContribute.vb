﻿Public Class frmContribute

    Private Sub frmContribute_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ApplyLocalizationToAllOpenForms()
        Me.Text = GetLocalizedText("x101")
        con_text1.Text = GetLocalizedText("x096")
        con_link.Text = GetLocalizedText("x100")
        con_text2.Text = GetLocalizedText("x097")
        con_notes.Text = GetLocalizedText("x099")
        con_text3.Text = GetLocalizedText("x098")
    End Sub

    Private Sub con_link_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles con_link.LinkClicked
        Try
            Process.Start("https://updftools.github.io/res/master_language.zip")
        Catch ex As Exception

        End Try
    End Sub
End Class