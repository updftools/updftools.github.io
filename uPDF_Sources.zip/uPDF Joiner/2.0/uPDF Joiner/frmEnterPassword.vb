﻿Public Class frmEnterPassword
    Public PDFPath As String
    Public PasswordInput As String
    Private Sub frmEnterPassword_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ApplyLocalizationToAllOpenForms()
        Me.Text = GetLocalizedText("x089")
        Label1.Text = GetLocalizedText("x045") & vbCrLf & PDFPath
        btn_ok.Text = GetLocalizedText("x059")
        btn_cancel.Text = GetLocalizedText("x058")
        TextBox1.Text = ""
        TextBox1.Focus()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_ok.Click
        Me.ActiveControl = Nothing
        If String.IsNullOrEmpty(TextBox1.Text) Then
            MessageBox.Show(GetLocalizedText("x046"), "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If
        PasswordInput = TextBox1.Text
        Me.DialogResult = Windows.Forms.DialogResult.OK
        Me.Close()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_cancel.Click
        Me.ActiveControl = Nothing
        Me.DialogResult = Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

    Private Sub TextBox1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox1.KeyPress
        If e.KeyChar = Chr(13) Then
            If String.IsNullOrEmpty(TextBox1.Text) Then
                MessageBox.Show(GetLocalizedText("x046"), "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Exit Sub
            End If
            PasswordInput = TextBox1.Text
            Me.DialogResult = Windows.Forms.DialogResult.OK
            Me.Close()
            e.Handled = True
        End If
    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged

    End Sub
End Class