﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("uPDF Joiner")> 
<Assembly: AssemblyDescription("Merge, Split, Extract — Fast & Easy.")> 
<Assembly: AssemblyCompany("Ari Sohandri Putra")> 
<Assembly: AssemblyProduct("uPDF Joiner")> 
<Assembly: AssemblyCopyright("© 2015 - 2025 Ari Sohandri Putra. All Rights Reserved.")> 
<Assembly: AssemblyTrademark("uPDF Joiner")> 

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("b3fb35c5-533d-4746-881b-16e8ceb508c4")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("2.1.0.0")> 
<Assembly: AssemblyFileVersion("2.1.0.0")> 
