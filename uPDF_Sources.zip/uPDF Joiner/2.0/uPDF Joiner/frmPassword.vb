﻿Public Class frmPassword

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_ok.Click
        Form1.userpass = TextBox1.Text
        Form1.ownerpass = TextBox2.Text
        Form1.savewithpass()
        Me.Close()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_cancel.Click
        Me.Close()
    End Sub

    Private Sub frmPassword_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ApplyLocalizationToAllOpenForms()
        Me.Text = GetLocalizedText("x091")
        crepass_user.Text = GetLocalizedText("x070")
        crepass_owner.Text = GetLocalizedText("x071")
        crepass_option.Text = GetLocalizedText("x072")
        btn_ok.Text = GetLocalizedText("x059")
        btn_cancel.Text = GetLocalizedText("x058")
    End Sub

    Private Sub TextBox2_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox2.KeyPress
        If e.KeyChar = Chr(13) Then
            Form1.userpass = TextBox1.Text
            Form1.ownerpass = TextBox2.Text
            Form1.savewithpass()
            Me.Close()
            e.Handled = True
        End If
    End Sub

    Private Sub TextBox2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox2.TextChanged

    End Sub

    Private Sub TextBox1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox1.KeyPress
        If e.KeyChar = Chr(13) Then
            TextBox2.Focus()
            e.Handled = True
        End If
    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub CheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked Then
            CheckBox2.Checked = False
            Form1.aestype = True
        Else
            CheckBox2.Checked = True
            Form1.aestype = False
        End If
    End Sub

    Private Sub CheckBox2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox2.CheckedChanged
        If CheckBox2.Checked Then
            CheckBox1.Checked = False
            Form1.aestype = False
        Else
            CheckBox1.Checked = True
            Form1.aestype = True
        End If
    End Sub
End Class