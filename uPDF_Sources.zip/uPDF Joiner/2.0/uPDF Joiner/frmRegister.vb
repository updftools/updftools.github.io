﻿Imports System.IO
Imports System.Management
Public Class frmRegister
    Private Function GetCpuId() As String
        Try
            Dim mc As New ManagementClass("win32_processor")
            Dim moc As ManagementObjectCollection = mc.GetInstances()
            For Each mo As ManagementObject In moc
                Return mo.Properties("ProcessorId").Value.ToString()
            Next
            Return "Unknown"
        Catch ex As Exception
            Return "Error: " & ex.Message
        End Try
    End Function
  
    Private Sub frmRegister_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ApplyLocalizationToAllOpenForms()
        Me.Text = GetLocalizedText("x092")
        TextBox1.Text = GetCpuId()
        btn_copy.Text = GetLocalizedText("x074")
        reg_buyreg.Text = GetLocalizedText("x076")
        reg_buyreg1.Text = GetLocalizedText("x077")
        btn_paypal.Text = GetLocalizedText("x083")
        reg_afterpurchase.Text = GetLocalizedText("x078")
        reg_info.Text = GetLocalizedText("x079")
        reg_key.Text = GetLocalizedText("x080")
        btn_reg.Text = GetLocalizedText("x081")
        btn_close.Text = GetLocalizedText("x082")
        reg_id.Text = GetLocalizedText("x073")
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_reg.Click
        Dim input As String = TextBox1.Text.Trim
        Dim serial As String = TextBox2.Text.Trim
        If input = "" Or serial = "" Then
            'MessageBox.Show("Isi kedua kolom terlebih dahulu!")
            Exit Sub
        End If
        Try
            Dim hashedInput As String = HashSHA256(input)
            Dim decryptedSerial As String = DecryptAES(serial)
            If hashedInput = decryptedSerial Then
                MsgBox(GetLocalizedText("x038"), vbExclamation, "Successful!")
                System.IO.File.WriteAllText(System.IO.Path.Combine(Application.StartupPath, "Reg.key"), TextBox2.Text)
                Application.Restart()
            Else
                MsgBox(GetLocalizedText("x039"), vbExclamation, "Error!")
            End If
        Catch ex As Exception
            MessageBox.Show(GetLocalizedText("x039") & vbCrLf & "Error")
        End Try
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_copy.Click
        Clipboard.SetText(TextBox1.Text)
        MsgBox(GetLocalizedText("x040"), vbInformation, "Copied!")
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_close.Click
        Me.Close()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim ofd As New OpenFileDialog()
        ofd.Filter = "Key Files (*.ky)|*.ky"
        ofd.Title = "Open Key File"
        If ofd.ShowDialog() = DialogResult.OK Then
            Try
                TextBox2.Text = System.IO.File.ReadAllText(ofd.FileName)
            Catch ex As Exception
                'MessageBox.Show("Gagal membuka: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_paypal.Click
        Try
            Process.Start("https://www.paypal.com/ncp/payment/JW3NGTAHJYCUG")
        Catch ex As Exception

        End Try
    End Sub
End Class