﻿Public Class frmExtractPages

    Private Sub frmExtractPages_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ApplyLocalizationToAllOpenForms()
        Me.Text = GetLocalizedText("x090")
        extract_filename.Text = GetLocalizedText("x064")
        extract_dir.Text = GetLocalizedText("x065")
        extract_date.Text = GetLocalizedText("x066")
        extract_size.Text = GetLocalizedText("x067")
        extract_pages.Text = GetLocalizedText("x068")
        extract_selectpages.Text = GetLocalizedText("x069")
        txt_statusextract.Text = GetLocalizedText("x049")
        btn_extract.Text = GetLocalizedText("x060")
        btn_cancel.Text = GetLocalizedText("x058")
        SetTextBoxPlaceholder()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_extract.Click
        Me.ActiveControl = Nothing
        If TextBox6.Text = GetLocalizedText("x041") OrElse TextBox6.Text = "" Then
            MsgBox(GetLocalizedText("x048"), vbExclamation, "Warning")
        Else
            If MessageBox.Show(GetLocalizedText("x042") & " (" & TextBox6.Text & ") " & GetLocalizedText("x043") & "(" & TextBox1.Text & ") " & GetLocalizedText("x044") & " [" & TextBox5.Text & "] ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) = DialogResult.Yes Then
                Form1.pagesinput = TextBox6.Text
                Form1.extractpages()
                Me.Close()
            Else
                TextBox6.Focus()
            End If
        End If

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_cancel.Click
        Me.ActiveControl = Nothing
        Me.Close()
    End Sub

    Private Sub TextBox6_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox6.GotFocus
        If TextBox6.ForeColor = Color.Gray Then
            TextBox6.Text = ""
            TextBox6.ForeColor = Color.Black
        End If
    End Sub

    Private Sub TextBox6_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox6.KeyPress
        If Not Char.IsDigit(e.KeyChar) AndAlso e.KeyChar <> ","c AndAlso e.KeyChar <> Chr(8) Then
            e.Handled = True ' Blokir karakter lain
        End If
        If e.KeyChar = Chr(13) Then
            If TextBox6.Text = GetLocalizedText("x041") OrElse TextBox6.Text = "" Then
                MsgBox(GetLocalizedText("x048"), vbExclamation, "Warning")
            Else
                If MessageBox.Show(GetLocalizedText("x042") & " (" & TextBox6.Text & ") " & GetLocalizedText("x043") & "(" & TextBox1.Text & ") " & GetLocalizedText("x044") & " [" & TextBox5.Text & "] ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) = DialogResult.Yes Then
                    Form1.pagesinput = TextBox6.Text
                    Form1.extractpages()
                    Me.Close()
                Else
                    TextBox6.Focus()
                End If
            End If
            e.Handled = True
        End If

    End Sub
    Private Sub SetTextBoxPlaceholder()
        TextBox6.Text = GetLocalizedText("x041")
        TextBox6.ForeColor = Color.Gray
    End Sub

    Private Sub TextBox6_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox6.LostFocus
        If TextBox6.Text = "" Then
            SetTextBoxPlaceholder()
        End If
    End Sub

    Private Sub TextBox6_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox6.TextChanged

    End Sub
End Class