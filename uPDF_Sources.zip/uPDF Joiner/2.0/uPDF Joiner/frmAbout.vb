﻿Public Class frmAbout

    Private Sub frmAbout_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ApplyLocalizationToAllOpenForms()
        Me.Text = GetLocalizedText("x088")
        lbtranslator.Text = GetLocalizedText("x001")
        lbtranslateby.Text = GetLocalizedText("x004") & " " & GetLocalizedText("x002") & " " & GetLocalizedText("x003")
        If Form1.lbtrial.Text = "Trial" Then
            Label3.Text = "Trial Version"
            Label3.BackColor = Color.MistyRose
        Else
            Label3.Text = "Pro Version"
            Label3.BackColor = Color.Turquoise
        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.Close()
    End Sub

    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Try
            Process.Start(System.IO.Path.Combine(Application.StartupPath, "eula.txt"))
        Catch ex As Exception

        End Try
    End Sub
End Class